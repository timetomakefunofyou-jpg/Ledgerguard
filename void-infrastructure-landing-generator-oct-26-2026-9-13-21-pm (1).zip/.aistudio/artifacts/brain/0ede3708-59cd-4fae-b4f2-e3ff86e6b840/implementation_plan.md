# LedgerGuard Executive Security & Intelligence Dashboard

A production-grade, dark-mode Web3 security command center adapted from the reference dashboard architecture. The dashboard combines institutional bytecode simulation, real-time threat telemetry, multi-chain DEX analytics, and clean zero-state user accounts powered by real Firebase Authentication and Cloud Firestore.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Key Directives Confirmed**:
> 1. **Public Landing Preserved**: As explicitly noted (*"Note do not change any thing in landing this is for dashboard"*), the high-converting public landing page, hero video, DEX screener, and launch playbook remain intact.
> 2. **Reference Dashboard Architecture**: Rebuilding `#dashboardView` to match the exact visual layout, card composition, and dark aesthetic of the uploaded reference (`1_xyxYJ3RIsHK56qkiMNjW2w_afe6ea85.png`).
> 3. **Exact Fonts & Video Asset**: Incorporating the requested CloudFront ambient video (`hf_20260809_012548_ef22562c-c0ae-4816-ad9d-f8922af4e6a7.mp4`), Inter, BubbledotICG-FinePos retro dot-matrix display typography, and Font Awesome 6.5.2 icons.
> 4. **Strict Zero-State Integrity ("No Predetails")**: The user explicitly instructed that when a user signs in, *"he should not see that these messages are there but I didn't send it"*. No fake placeholder chat logs, mock user audits, or dummy transactions will ever be attributed to the logged-in user. Personal lists will load strictly from the user's Firestore document with pristine empty states and actionable scan prompts.
> 5. **Every Chart Fully Interactive**: The dual-curve spline chart, audit activity calendar, segmented chain bar chart, risk donut chart, and stippled global threat node map will all be fully functional with live tooltips, timeframe tabs, and click handlers.

---

## 1. Overview & Core Concept

- **What It Does**: Once authenticated via Google or Email/Password, users are redirected seamlessly to an institutional-grade Web3 security dashboard (`#dashboard`). The dashboard presents live multi-chain intelligence, interactive threat curves, audited smart contract activity, chain breakdown, global validator nodes, and a dedicated personal watchlist and audit log manager.
- **Target Audience**: Web3 traders, meme coin investors, security researchers, and token creators requiring real-time bytecode analysis without fake demo bloat.
- **Key Value**: Replaces generic static scoreboards with functional interactive visual instruments, authentic real-time data from DexScreener, GoPlus, and RugCheck, and deterministic Firebase Cloud synchronization.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Authentication & Automatic Redirect**:
   - The user clicks **Sign In** (desktop topbar or mobile burger menu) or enters their credentials in the modal.
   - Upon successful sign-in via Google Popup or Email/Password, the application updates Firebase auth state and immediately routes to `#dashboard`.
2. **Dashboard Overview (The 7 Core Visual Cards)**:
   - **Header**: Wordmark + white active nav pill (`Overview`, `Threat Analytics`, `Audit Activity`, `Holdings`) + Search bar (`Ctrl+K` token search) + User profile pill (avatar, display name, account tier).
   - **Card 1: Value & Threat Exposure Chart (Wide Top-Left)**:
     - Dual glowing spline area curves with interactive hover crosshairs and tooltips (`$2,894` Exposure / `287` Intercepts).
     - Working timeframe switcher pills: `Today`, `Week`, `Month`, `Range`.
     - Live KPI indicators with percentage changes (+2.4% / +4.7%).
   - **Card 2: Security Audit Activity Calendar (Top-Center)**:
     - Interactive calendar widget with month navigation, active security scan dates with glowing indicator dots, selectable day badge, and total shielded capital counter (`$18,434`).
   - **Card 3: Chain Interceptions & Volume (Top-Right)**:
     - Segmented vertical bar chart with diagonal hatch patterns across weekdays (`Mon` to `Sun`).
     - Platform/Chain pill switcher: `EVM Networks` vs `Solana`.
     - Real-time callout badges (`562` clean deployments, `286` blocked honeypots).
   - **Card 4: Monitored Contracts / Watchlist (Bottom-Left)**:
     - Token thumbnails, ticker symbols, risk category tags (`Safe 97/100`, `Honeypot 16/100`), and 24h trading volume badges (`39k`, `31k`, `27k`).
     - Clean zero-state when empty with a "+ Track First Token" trigger.
   - **Card 5: Risk & Authority Distribution (Bottom Donut)**:
     - Multi-segment SVG Donut chart displaying liquidity lock ratios: `46% Burned LP`, `32% Locked 365d`, `18% Short Lock`, `4% Unlocked Risk`.
     - Interactive slice hover showing exact token counts and percentages.
   - **Card 6: Global Threat Node Network (Bottom-Center)**:
     - Stippled dot-matrix world map with illuminated, pulsing RPC node coordinates across North America, Europe, Asia, and Australia.
     - Live hover tooltips revealing regional node latency and blocked exploits.
   - **Card 7: Volume & Incident Distribution by Chain/Region (Bottom-Right)**:
     - Country and network rankings with regional flags (`USA 43,987`, `Australia 32,648`, `Germany 26,563`, `Spain 21,514`, `Argentina 43,987`).
     - Clickable rows that filter the global map and threat radar.
3. **Deep Token Audit Modal & Pro Charts**:
   - Clicking any token or running a search opens the TradingView Lightweight Charts modal with GoPlus and RugCheck security flags, live buy/sell taxes, and ownership renunciation proofs.

### Visual Identity & Theme
- **Dominant Neutral Canvas (60%)**: Obsidian black (`#000000` / `#07080a`) with atmospheric depth provided by the CloudFront ambient video running at low opacity with a protective vignette scrim.
- **Structural Surfaces (30%)**: Deep dark obsidian cards (`#0c0e14` / `#12151c`) with hairline borders (`1px solid rgba(255, 255, 255, 0.08)`) and 20px rounded corners matching the Fitonist reference.
- **Accent Budget (10%)**:
  - Emerald green (`#10b981`) for verified safe contracts and active nodes.
  - Electric crimson (`#ef4444`) for honeypot warnings and rug exploits.
  - Soft lilac/violet (`#c084fc`) and warm amber (`#f59e0b`) for dual chart curves and calendar highlight states.
- **Typography**:
  - UI Sans: `Inter` (weights 400, 500, 600) for dense scannability.
  - Display Face: `BubbledotICG-FinePos` (retro dot-matrix) via OnlineWebFonts CDN for headline indicators and telemetry counters.
  - Monospace Data: `font-mono tabular-nums` for prices, timestamps, and wallet addresses.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-View Routing in Single-Page Architecture**:
  - *Chosen Approach*: Maintain `#landingView` and `#dashboardView` in `index.html`, synchronized via hash routing (`#/` vs `#dashboard`).
  - *Why*: Provides zero-latency view switching without full page reloads, preserves video playback smoothly, and allows instant return to the landing page anytime via the topbar or "Landing & Screener" button.
- **Decision 2: Clean Zero-State vs. Mock Historical Messages**:
  - *Chosen Approach*: Pure user-owned Firestore collections (`users/{uid}/watchlist` and `users/{uid}/auditLogs`). When a new user logs in, render a pristine, beautifully styled zero state with an onboarding card ("Scan your first token or add from the live screener") rather than injecting fake pre-written user logs or messages.
  - *Why*: Completely adheres to the user's explicit directive: *"no predetails will be there like when user redirect he should not see that these messages are there but I didn't send it"*.
- **Decision 3: Canvas & SVG-Based Data Visualizations**:
  - *Chosen Approach*: Native interactive SVG for the dual spline curve, segmented bar chart, donut chart, and stippled dot-matrix world map, combined with TradingView Lightweight Charts for detailed token candlestick analysis.
  - *Why*: Ultra-fast rendering (<16ms frame budget), zero external dependency bloat, crisp resolution on retina displays, and full control over tooltips and animations.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        LEDGERGUARD RUNTIME                              │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [Top Navigation: Brand Wordmark + Route Switcher + Wallet + Auth]    │
│                                                                        │
│  ┌───────────────────────────┐      ┌───────────────────────────────┐  │
│  │     #landingView          │      │       #dashboardView          │  │
│  │ (Cinematic Video, DEX     │◄────►│  (Fitonist 7-Card Grid,       │  │
│  │  Screener, Rug Sim, FAQ)  │      │   Interactive Live Charts,    │  │
│  │                           │      │   Firestore Sync, Clean State)│  │
│  └───────────────────────────┘      └───────────────────────────────┘  │
│                                                     │                  │
│                                      ┌──────────────┴──────────────┐   │
│                                      │   7 Interactive Card Units  │   │
│                                      ├─────────────────────────────┤   │
│                                      │ 1. Value/Threat Dual Curve  │   │
│                                      │ 2. Audit Activity Calendar  │   │
│                                      │ 3. Chain Exploit Bar Chart  │   │
│                                      │ 4. Personal Watchlist Table │   │
│                                      │ 5. Liquidity Risk Donut     │   │
│                                      │ 6. Global Stippled Node Map │   │
│                                      │ 7. Regional RPC Rankings    │   │
│                                      └──────────────┬──────────────┘   │
│                                                     │                  │
│                     ┌───────────────────────────────┴────────────────┐ │
│                     │           CLIENT SERVICES LAYER                │ │
│                     ├────────────────────────────────────────────────┤ │
│                     │ · Firebase Auth (Google Popup & Email/Pass)    │ │
│                     │ · Cloud Firestore (`users/{uid}/watchlist`)    │ │
│                     │ · Multi-Chain Wallet Connect (EVM & Solana)   │ │
│                     │ · DexScreener Live Pool Telemetry API          │ │
│                     │ · GoPlus & RugCheck Security Engine Proxy      │ │
│                     └────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Reactive Handlers
- **User Watchlist**: Stored in `users/{uid}/watchlist/{tokenKey}`. Real-time updates via Firestore `onSnapshot`.
- **User Audit History**: Stored in `users/{uid}/auditLogs/{logId}`. Contains timestamped records of contracts inspected by the user.
- **Global Intelligence Telemetry**: Live pool updates fetched from DexScreener and processed through the bytecode security grader.
- **State Cleanup on Logout**: When a user logs out, active Firestore listeners are immediately unsubscribed and the UI returns to the landing view with all personal data cleared from DOM memory.
