import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateEmail,
  validatePassword,
  createSession,
  formatUserInitials,
  calculateResponsiveUnits,
} from './auth.ts';

test('validateEmail correctly accepts valid emails', () => {
  assert.equal(validateEmail('dev@layer-ai.internal'), true);
  assert.equal(validateEmail('founder@startup.io'), true);
  assert.equal(validateEmail('user.name+tag@domain.co.uk'), true);
});

test('validateEmail rejects invalid emails', () => {
  assert.equal(validateEmail('invalid'), false);
  assert.equal(validateEmail('invalid@'), false);
  assert.equal(validateEmail('@domain.com'), false);
  assert.equal(validateEmail(''), false);
});

test('validatePassword validates length constraint', () => {
  assert.equal(validatePassword('12345').valid, false);
  assert.equal(validatePassword('123456').valid, true);
  assert.equal(validatePassword('SecurePass2026!').valid, true);
});

test('createSession generates valid session payload', () => {
  const session = createSession('dev@layer-ai.internal', 'Test Org');
  assert.equal(session.email, 'dev@layer-ai.internal');
  assert.equal(session.org, 'Test Org');
  assert.match(session.token, /^layer_tok_/);
  assert.ok(session.timestamp > 0);
});

test('formatUserInitials extracts correct uppercase letters', () => {
  assert.equal(formatUserInitials('dev@layer-ai.internal'), 'DE');
  assert.equal(formatUserInitials('alex@company.com'), 'AL');
  assert.equal(formatUserInitials('z@company.com'), 'Z');
});

test('calculateResponsiveUnits computes exact ratio for reference canvas 1487x1058', () => {
  const { u, uw, h } = calculateResponsiveUnits(1487, 1058);
  assert.equal(u, 1);
  assert.equal(uw, 1);
  assert.equal(h, 1);
});

test('calculateResponsiveUnits clamps h between u and 1.16 * u', () => {
  // Very wide screen: 3000 x 1058 (u = 1, uw = 2.017)
  const wide = calculateResponsiveUnits(3000, 1058);
  assert.equal(wide.u, 1);
  assert.equal(wide.h, 1.16); // clamped to max 1.16

  // Narrow screen: 500 x 1058 (u = 1, uw = 0.336)
  const narrow = calculateResponsiveUnits(500, 1058);
  assert.equal(narrow.u, 1);
  assert.equal(narrow.h, 1.0); // clamped to min u
});
