import test from 'node:test';
import assert from 'node:assert/strict';
import {
  auditTokenContract,
  validateContractAddress,
  getCreatorPlaybook,
  calculateLaunchReadiness,
  getThreatSimulationData,
} from './audit.ts';

test('validateContractAddress correctly identifies valid EVM and Solana addresses', () => {
  assert.equal(validateContractAddress('0x6982508145454ce325ddbe47a25d4ec3d2311933'), true);
  assert.equal(validateContractAddress('DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263'), true);
  assert.equal(validateContractAddress('invalid_address_123'), false);
  assert.equal(validateContractAddress(''), false);
});

test('auditTokenContract correctly flags high-risk honeypot token', () => {
  const result = auditTokenContract('scam');
  assert.equal(result.isHoneypot, true);
  assert.equal(result.sellTax, 99);
  assert.equal(result.status, 'high_risk_rug');
  assert.ok(result.safetyScore < 30);
  assert.ok(result.threatFlags.length >= 3);
});

test('auditTokenContract validates safe token metrics', () => {
  const result = auditTokenContract('pepe');
  assert.equal(result.isHoneypot, false);
  assert.equal(result.sellTax, 0);
  assert.equal(result.status, 'verified_safe');
  assert.equal(result.liquidityLockedPercent, 100);
  assert.ok(result.safetyScore > 90);
  assert.ok(result.realBuyerRatio > 90);
});

test('calculateLaunchReadiness returns A+ for perfect creator configuration', () => {
  const readiness = calculateLaunchReadiness({
    liquidityLocked: true,
    lockDurationDays: 365,
    mintRevoked: true,
    freezeRevoked: true,
    sellTax: 0,
    maxWalletCapPercent: 1.5,
  });
  assert.equal(readiness.grade, 'A+');
  assert.equal(readiness.score, 100);
  assert.equal(readiness.isLaunchReady, true);
  assert.equal(readiness.criticalIssues.length, 0);
});

test('calculateLaunchReadiness detects critical security hazards', () => {
  const readiness = calculateLaunchReadiness({
    liquidityLocked: false,
    lockDurationDays: 0,
    mintRevoked: false,
    freezeRevoked: false,
    sellTax: 15,
    maxWalletCapPercent: 10,
  });
  assert.equal(readiness.grade, 'F');
  assert.ok(readiness.score <= 30);
  assert.equal(readiness.isLaunchReady, false);
  assert.ok(readiness.criticalIssues.length >= 3);
});

test('getThreatSimulationData produces accurate comparative time series', () => {
  const sim = getThreatSimulationData();
  assert.equal(sim.length, 6);
  assert.equal(sim[0].unprotectedLiquiditySol, 250);
  assert.equal(sim[sim.length - 1].unprotectedLiquiditySol, 0);
  assert.ok(sim[sim.length - 1].protectedCapitalSavedSol > 450);
});

test('getCreatorPlaybook returns all 5 sequential launch steps', () => {
  const playbook = getCreatorPlaybook();
  assert.equal(playbook.length, 5);
  assert.equal(playbook[0].step, 1);
  assert.equal(playbook[4].step, 5);
});
