/**
 * Pure authentication & layout utility functions for Layer AI Infrastructure
 */

export interface UserSession {
  email: string;
  org: string;
  token: string;
  timestamp: number;
}

export function validateEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.trim());
}

export function validatePassword(password: string): { valid: boolean; error?: string } {
  if (!password || typeof password !== 'string') {
    return { valid: false, error: 'Password is required' };
  }
  if (password.length < 6) {
    return { valid: false, error: 'Password must be at least 6 characters' };
  }
  return { valid: true };
}

export function createSession(email: string, org?: string): UserSession {
  const cleanEmail = email.trim();
  const cleanOrg = org?.trim() || 'Enterprise Workspace';
  const token = 'layer_tok_' + Math.random().toString(36).substring(2, 12);
  return {
    email: cleanEmail,
    org: cleanOrg,
    token,
    timestamp: Date.now(),
  };
}

export function formatUserInitials(email: string): string {
  if (!email) return 'DV';
  const namePart = email.split('@')[0] || '';
  if (namePart.length >= 2) {
    return namePart.substring(0, 2).toUpperCase();
  }
  return (namePart[0] || 'D').toUpperCase();
}

/**
 * Responsive calculation according to comp specs:
 * Reference canvas: 1487 x 1058
 * u = vh / 1058
 * uw = vw / 1487
 * h = clamp(u, u * 0.65 + uw * 0.35, u * 1.16)
 */
export function calculateResponsiveUnits(viewportWidth: number, viewportHeight: number) {
  const u = viewportHeight / 1058;
  const uw = viewportWidth / 1487;
  const rawH = u * 0.65 + uw * 0.35;
  const minH = u;
  const maxH = u * 1.16;
  const h = Math.min(Math.max(rawH, minH), maxH);
  return { u, uw, h };
}
