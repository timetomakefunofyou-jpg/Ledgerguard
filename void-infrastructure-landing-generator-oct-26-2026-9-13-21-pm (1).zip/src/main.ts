/**
 * LedgerGuard Enterprise Master Client
 * Multi-Chain Web3 Wallet Connect + TradingView Lightweight Charts + Firebase Cloud Auth & Database
 */

import {
  auth,
  loginWithGoogle,
  loginWithEmail,
  registerWithEmail,
  logoutUser,
  subscribeUserWatchlist,
  addToWatchlist,
  removeFromWatchlist,
  recordAuditLog,
  subscribeUserAuditLogs,
  WatchlistToken,
  AuditRecord
} from './services/firebase';
import { walletService, WalletState } from './services/wallet';
import { TokenChartController, ChartMode, Timeframe } from './components/chart';
import {
  scanTokenSecurity,
  requestAiSecurityAudit,
  SecurityScanResult,
  searchDexPair,
  generateMakerLaunchPlan,
  MakerPlanResponse
} from './services/security';
import { onAuthStateChanged, User } from 'firebase/auth';

// ─── STATE MANAGEMENT ───
let currentUser: User | null = null;
let currentWatchlist: WatchlistToken[] = [];
let currentAuditLogs: AuditRecord[] = [];
let activeChartController: TokenChartController | null = null;
let activePairForModal: any = null;

let unsubscribeWatchlist: (() => void) | null = null;
let unsubscribeAuditLogs: (() => void) | null = null;

// Helper: Format USD Currency
function formatUsd(num: any): string {
  if (!num || isNaN(num)) return '$0.00';
  const n = Number(num);
  if (n >= 1e9) return '$' + (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return '$' + (n / 1e3).toFixed(1) + 'K';
  return '$' + n.toLocaleString();
}

function formatPrice(priceStr: any): string {
  const p = parseFloat(priceStr);
  if (!p || isNaN(p)) return '$0.00';
  if (p < 0.000001) return '$' + p.toExponential(4);
  if (p < 0.001) return '$' + p.toFixed(6);
  if (p < 1) return '$' + p.toFixed(4);
  return '$' + p.toFixed(2);
}

// ─── INITIALIZATION ON DOM READY ───
function initApp() {
  setupTopbarButtons();
  setupModalsMarkup();
  setupAuthListeners();
  setupWalletListeners();
  setupRoutingAndViews();
  setupDashboardEventListeners();
  hookDexScreenerEvents();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

// ─── TOPBAR & MOBILE NAVIGATION ───
function setupTopbarButtons() {
  const topbar = document.querySelector('header.topbar');
  if (!topbar) return;

  // Insert actions container before mobile burger button
  const burger = document.getElementById('burger');
  const navLinks = topbar.querySelector('nav.links');

  // Replace default button with our Web3 & Auth Action Cluster
  const defaultPill = document.getElementById('btnHeaderApp');
  if (defaultPill) defaultPill.remove();

  const actionsWrap = document.createElement('div');
  actionsWrap.className = 'topbar-actions-cluster';
  actionsWrap.innerHTML = `
    <!-- Watchlist trigger -->
    <button id="btnHeaderWatchlist" class="btn-topbar-ghost" title="Your Cloud Watchlist" style="display: none;">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
      <span class="btn-label font-bold">Watchlist</span>
      <span id="headerWatchlistCount" class="badge-count">0</span>
    </button>

    <!-- Real Web3 Wallet Connect -->
    <button id="btnConnectWallet" class="btn-wallet-connect font-bold" title="Connect Multi-chain Web3 Wallet">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M16 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg>
      <span id="walletBtnLabel">${window.innerWidth <= 640 ? 'Connect' : 'Connect Wallet'}</span>
    </button>

    <!-- Real Firebase Auth Button -->
    <button id="btnUserAuth" class="btn-auth-user font-bold" title="Sign In or Open Dashboard">
      <span id="authUserAvatar" class="auth-avatar-circle">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </span>
      <span id="authUserLabel">Sign In</span>
    </button>
  `;

  if (burger) {
    topbar.insertBefore(actionsWrap, burger);
  } else {
    topbar.appendChild(actionsWrap);
  }

  // Bind clicks
  document.getElementById('btnConnectWallet')?.addEventListener('click', handleWalletBtnClick);
  document.getElementById('btnUserAuth')?.addEventListener('click', handleAuthBtnClick);
  document.getElementById('btnHeaderWatchlist')?.addEventListener('click', openWatchlistDrawer);

  // Inject into Mobile Drawer too
  const mobileDrawer = document.getElementById('mobileDrawer');
  if (mobileDrawer) {
    const mobileActions = document.createElement('div');
    mobileActions.className = 'mobile-drawer-auth-box';
    mobileActions.innerHTML = `
      <div style="font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; margin-bottom: 8px;">Account &amp; Web3</div>
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <button id="btnMobileWallet" class="btn-wallet-connect font-bold" style="width: 100%; justify-content: center;">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M16 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg>
          <span id="mobileWalletBtnLabel">Connect Wallet</span>
        </button>
        <button id="btnMobileAuth" class="btn-auth-user font-bold" style="width: 100%; justify-content: center;">
          <span id="mobileAuthUserLabel">Sign In</span>
        </button>
      </div>
    `;
    mobileDrawer.prepend(mobileActions);

    document.getElementById('btnMobileWallet')?.addEventListener('click', () => {
      mobileDrawer.classList.remove('is-open');
      handleWalletBtnClick();
    });
    document.getElementById('btnMobileAuth')?.addEventListener('click', () => {
      mobileDrawer.classList.remove('is-open');
      handleAuthBtnClick();
    });
  }
}

// ─── INJECT MODALS MARKUP ───
function setupModalsMarkup() {
  const container = document.createElement('div');
  container.id = 'ledgerguardModalsContainer';
  container.innerHTML = `
    <!-- 1. MULTI-CHAIN WALLET SELECTOR MODAL -->
    <div class="modal-overlay" id="modalWalletSelector">
      <div class="modal-content wallet-modal-card">
        <div class="modal-header">
          <div class="modal-title-wrap">
            <h2>Connect Multi-Chain Web3 Wallet</h2>
            <p>Connect your browser wallet to verify trades and execute real-time audits.</p>
          </div>
          <button class="modal-close-btn" id="closeWalletSelector" aria-label="Close modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="wallet-chain-group-label">EVM NETWORKS (Ethereum, Base, BNB, Arbitrum)</div>
          <div class="wallet-options-grid">
            <button class="wallet-option-btn" id="walletOptMetaMask">
              <div class="wallet-icon-wrap" style="background: rgba(246, 133, 27, 0.15);">🦊</div>
              <div class="wallet-info">
                <div class="wallet-name font-bold">MetaMask</div>
                <div class="wallet-sub" id="statusMetaMask">Checking...</div>
              </div>
              <div class="wallet-tag">EVM</div>
            </button>
            <button class="wallet-option-btn" id="walletOptRabby">
              <div class="wallet-icon-wrap" style="background: rgba(134, 151, 246, 0.15);">🐰</div>
              <div class="wallet-info">
                <div class="wallet-name font-bold">Rabby Wallet</div>
                <div class="wallet-sub" id="statusRabby">Checking...</div>
              </div>
              <div class="wallet-tag">EVM</div>
            </button>
            <button class="wallet-option-btn" id="walletOptCoinbase">
              <div class="wallet-icon-wrap" style="background: rgba(0, 82, 255, 0.15);">🔵</div>
              <div class="wallet-info">
                <div class="wallet-name font-bold">Coinbase Wallet</div>
                <div class="wallet-sub" id="statusCoinbase">Checking...</div>
              </div>
              <div class="wallet-tag">Base / EVM</div>
            </button>
          </div>

          <div class="wallet-chain-group-label" style="margin-top: 20px;">SOLANA ECOSYSTEM (Raydium, Pump.fun)</div>
          <div class="wallet-options-grid">
            <button class="wallet-option-btn" id="walletOptPhantom">
              <div class="wallet-icon-wrap" style="background: rgba(171, 159, 242, 0.15);">👻</div>
              <div class="wallet-info">
                <div class="wallet-name font-bold">Phantom</div>
                <div class="wallet-sub" id="statusPhantom">Checking...</div>
              </div>
              <div class="wallet-tag">Solana</div>
            </button>
            <button class="wallet-option-btn" id="walletOptSolflare">
              <div class="wallet-icon-wrap" style="background: rgba(255, 116, 38, 0.15);">🔥</div>
              <div class="wallet-info">
                <div class="wallet-name font-bold">Solflare</div>
                <div class="wallet-sub" id="statusSolflare">Checking...</div>
              </div>
              <div class="wallet-tag">Solana</div>
            </button>
          </div>

          <div id="walletErrorAlert" class="error-banner" style="display: none; margin-top: 16px;"></div>
        </div>
      </div>
    </div>

    <!-- 2. WALLET DETAILS MODAL (CONNECTED STATE) -->
    <div class="modal-overlay" id="modalWalletDetails">
      <div class="modal-content wallet-details-card">
        <div class="modal-header">
          <div class="modal-title-wrap">
            <h2>Connected Web3 Wallet</h2>
            <p id="walletConnectedNetTitle">Active on Network</p>
          </div>
          <button class="modal-close-btn" id="closeWalletDetails">✕</button>
        </div>
        <div class="modal-body">
          <div class="wallet-account-strip">
            <div class="wallet-avatar-big" id="walletBigAvatar">⚡</div>
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span class="font-bold text-white" id="walletDetailName">MetaMask</span>
                <span class="chain-pill" id="walletDetailChainPill">Base</span>
              </div>
              <div class="wallet-address-copy font-bold" id="walletDetailFullAddress" title="Click to copy full address">
                0x000...0000 <span>📋</span>
              </div>
            </div>
          </div>

          <div class="wallet-balance-card">
            <div class="balance-label">Verified Wallet Balance</div>
            <div class="balance-amount font-extrabold" id="walletDetailBalance">0.0000 ETH</div>
          </div>

          <div id="evmChainSwitchBlock" style="margin-top: 18px;">
            <div style="font-size: 12px; font-weight: 800; color: #94a3b8; text-transform: uppercase; margin-bottom: 8px;">Switch Active EVM Chain</div>
            <div class="chain-switch-buttons">
              <button class="chain-switch-btn font-bold" data-evm-chain="0x2105">Base (8453)</button>
              <button class="chain-switch-btn font-bold" data-evm-chain="0x1">Ethereum (1)</button>
              <button class="chain-switch-btn font-bold" data-evm-chain="0x38">BNB Chain (56)</button>
              <button class="chain-switch-btn font-bold" data-evm-chain="0xa4b1">Arbitrum (42161)</button>
            </div>
          </div>

          <div style="margin-top: 24px; display: flex; gap: 12px;">
            <button class="pill-cta" id="btnDisconnectWallet" style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #f87171; width: 100%;">
              Disconnect Wallet
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 3. REAL FIREBASE AUTH MODAL -->
    <div class="modal-overlay" id="modalAuth">
      <div class="modal-content auth-modal-card">
        <div class="modal-header">
          <div class="modal-title-wrap">
            <h2>LedgerGuard Cloud Account</h2>
            <p>Save custom watchlists, sync real-time contract audits, and track honeypot alerts.</p>
          </div>
          <button class="modal-close-btn" id="closeAuthModal">✕</button>
        </div>
        <div class="modal-body">
          <!-- Google 1-Click Auth -->
          <button class="google-auth-btn font-bold" id="btnGoogleAuth">
            <svg viewBox="0 0 24 24" width="18" height="18">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            <span>Continue with Google</span>
          </button>

          <div class="auth-divider">
            <span>OR USE EMAIL</span>
          </div>

          <!-- Auth Tabs -->
          <div class="auth-tabs-row">
            <button class="auth-tab is-active font-bold" id="tabSignIn">Sign In</button>
            <button class="auth-tab font-bold" id="tabSignUp">Create Account</button>
          </div>

          <form id="emailAuthForm" class="auth-form" onsubmit="return false;">
            <div class="form-group">
              <label class="form-label font-bold" for="authEmailInput">Email Address</label>
              <input type="email" id="authEmailInput" class="form-input" placeholder="trader@ledgerguard.com" required autocomplete="email">
            </div>

            <div class="form-group">
              <label class="form-label font-bold" for="authPasswordInput">Password</label>
              <input type="password" id="authPasswordInput" class="form-input" placeholder="••••••••••••" required autocomplete="current-password">
            </div>

            <div id="authErrorMessage" class="error-banner" style="display: none;"></div>

            <button type="submit" class="pill-cta font-bold" id="btnSubmitEmailAuth" style="width: 100%; margin-top: 10px;">
              Sign In to LedgerGuard
            </button>
          </form>
        </div>
      </div>
    </div>

    <!-- 4. USER PROFILE & CLOUD WATCHLIST DRAWER -->
    <div class="modal-overlay" id="modalWatchlistDrawer">
      <div class="modal-content watchlist-drawer-card">
        <div class="modal-header">
          <div class="modal-title-wrap">
            <h2>Your Cloud Workspace</h2>
            <p id="userProfileEmail">Signed in as ...</p>
          </div>
          <button class="modal-close-btn" id="closeWatchlistDrawer">✕</button>
        </div>
        <div class="modal-body" style="padding-top: 16px;">
          <!-- Workspace Tabs -->
          <div class="auth-tabs-row" style="margin-bottom: 16px;">
            <button class="auth-tab is-active font-bold" id="tabWatchlist">Watched Tokens (<span id="countWatchlistTab">0</span>)</button>
            <button class="auth-tab font-bold" id="tabAuditHistory">Recent Audits (<span id="countAuditsTab">0</span>)</button>
          </div>

          <!-- Watchlist Content -->
          <div id="watchlistTabContent">
            <div id="watchlistItemsList" class="watchlist-items-list">
              <!-- Populated dynamically -->
            </div>
            <div id="watchlistEmptyState" class="empty-state-box" style="display: none;">
              <div style="font-size: 28px; margin-bottom: 8px;">⭐</div>
              <div class="font-bold text-white">Your watchlist is empty</div>
              <p style="font-size: 13px; color: #94a3b8; margin-top: 4px;">Click the star icon next to any token in the Live DEX Screener to track it in real-time.</p>
            </div>
          </div>

          <!-- Audit History Content -->
          <div id="auditHistoryTabContent" style="display: none;">
            <div id="auditHistoryList" class="watchlist-items-list">
              <!-- Populated dynamically -->
            </div>
            <div id="auditHistoryEmptyState" class="empty-state-box" style="display: none;">
              <div style="font-size: 28px; margin-bottom: 8px;">🛡️</div>
              <div class="font-bold text-white">No audits recorded yet</div>
              <p style="font-size: 13px; color: #94a3b8; margin-top: 4px;">Scan any meme coin contract to record cryptographic bytecode security proofs.</p>
            </div>
          </div>

          <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid rgba(255, 255, 255, 0.08); display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 12px; color: #64748b; font-weight: 700;">Firestore Real-Time Sync</span>
            <button class="ghost-cta font-bold" id="btnLogoutUser" style="padding: 8px 16px; font-size: 13px; color: #f87171; border-color: rgba(239, 68, 68, 0.2);">
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 5. UPGRADED PRO CHART & AUDIT MODAL -->
    <div class="modal-overlay" id="modalProChart">
      <div class="modal-content pro-chart-modal-card">
        <!-- Header -->
        <div class="chart-modal-header">
          <div class="chart-modal-token-meta">
            <div class="token-title-row">
              <span class="token-name-badge font-extrabold" id="chartTokenSymbol">$PEPE</span>
              <span class="token-full-name font-bold" id="chartTokenName">Pepe Coin</span>
              <span class="chain-pill" id="chartChainPill">Ethereum</span>
              <span class="dex-pill" id="chartDexPill">Uniswap</span>
              <span class="provider-pill font-bold" id="chartProviderBadge">Automated Bytecode Security</span>
            </div>
            <div class="token-sub-row">
              <span class="contract-copy font-bold" id="chartContractCopy" title="Click to copy contract">0x000...000 [Copy]</span>
              <span class="divider-dot">·</span>
              <span class="verified-safe-tag font-bold" id="chartSafetyVerdict">VERIFIED SAFE</span>
            </div>
          </div>

          <div class="chart-modal-actions">
            <!-- Watchlist toggle -->
            <button class="btn-star-toggle font-bold" id="btnToggleChartWatchlist" title="Add to Watchlist">
              <span id="starIcon">☆</span>
              <span id="starLabel">Watch</span>
            </button>
            <button class="modal-close-btn" id="closeProChartModal">✕</button>
          </div>
        </div>

        <!-- Pro Chart Toolbar & Price Bar -->
        <div class="pro-chart-toolbar">
          <div class="price-summary-strip">
            <div class="price-val font-extrabold" id="chartPriceUsd">$0.000000</div>
            <div class="change-badge font-bold" id="chartPriceChange">+0.00%</div>
            <div class="stat-mini font-bold">Vol 24h: <span id="chartVol24h">$0.00</span></div>
            <div class="stat-mini font-bold">Liq: <span id="chartLiqUsd">$0.00</span></div>
          </div>

          <div class="chart-controls-cluster">
            <!-- Timeframe switcher -->
            <div class="timeframe-buttons">
              <button class="tf-btn is-active font-bold" data-tf="15m">15m</button>
              <button class="tf-btn font-bold" data-tf="1h">1h</button>
              <button class="tf-btn font-bold" data-tf="4h">4h</button>
              <button class="tf-btn font-bold" data-tf="1D">1D</button>
            </div>

            <!-- Candlestick vs Area Switcher -->
            <div class="mode-buttons">
              <button class="mode-btn is-active font-bold" id="btnModeCandles" title="Candlestick Chart">🕯 Candles</button>
              <button class="mode-btn font-bold" id="btnModeArea" title="Area Line Chart">📈 Area</button>
            </div>
          </div>
        </div>

        <!-- Real-time Crosshair HUD Strip -->
        <div class="crosshair-hud font-bold" id="crosshairHud">
          <span>O: <strong id="hudOpen">-</strong></span>
          <span>H: <strong id="hudHigh">-</strong></span>
          <span>L: <strong id="hudLow">-</strong></span>
          <span>C: <strong id="hudClose">-</strong></span>
          <span>Vol: <strong id="hudVol">-</strong></span>
          <span id="hudChg" style="color: #34d399;">+0.00%</span>
        </div>

        <!-- TradingView Lightweight Charts Canvas Host -->
        <div class="tradingview-canvas-wrap" id="chartCanvasHost"></div>

        <!-- Threat Flags Alert Container (Rendered when warnings exist) -->
        <div class="threat-flags-box" id="chartThreatFlagsBox" style="display: none; margin: 12px 24px 0;">
          <div class="threat-flags-title font-bold">⚠️ On-Chain Threat Warnings Detected</div>
          <ul id="chartThreatFlagsList"></ul>
        </div>

        <!-- Comprehensive Security Audit Matrix (Powered by GoPlus & RugCheck) -->
        <div class="chart-audit-strip">
          <div class="audit-card">
            <div class="audit-card-label">Honeypot &amp; Slippage Taxes</div>
            <div class="audit-card-val font-extrabold" id="chartCardHoneypot">Scanning...</div>
          </div>
          <div class="audit-card">
            <div class="audit-card-label">Mint &amp; Freeze Authorities</div>
            <div class="audit-card-val font-extrabold" id="chartCardAuthorities">Scanning...</div>
          </div>
          <div class="audit-card">
            <div class="audit-card-label">LP Locker &amp; Burn Status</div>
            <div class="audit-card-val font-extrabold" id="chartCardLiquidity">Scanning...</div>
          </div>
          <div class="audit-card">
            <div class="audit-card-label">Top 10 Whale Concentration</div>
            <div class="audit-card-val font-extrabold" id="chartCardWhales">Scanning...</div>
          </div>
          <div class="audit-card">
            <div class="audit-card-label">Ownership Renunciation</div>
            <div class="audit-card-val font-extrabold" id="chartCardOwnership">Scanning...</div>
          </div>
          <div class="audit-card">
            <div class="audit-card-label">Retail vs Wash Trading</div>
            <div class="audit-card-val font-extrabold" id="chartCardWash">94.2% Organic Retail</div>
          </div>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  // Close handlers
  document.getElementById('closeWalletSelector')?.addEventListener('click', () => closeAllModals());
  document.getElementById('closeWalletDetails')?.addEventListener('click', () => closeAllModals());
  document.getElementById('closeAuthModal')?.addEventListener('click', () => closeAllModals());
  document.getElementById('closeWatchlistDrawer')?.addEventListener('click', () => closeAllModals());
  document.getElementById('closeProChartModal')?.addEventListener('click', () => closeProChartModal());

  // Wallet options clicks
  document.getElementById('walletOptMetaMask')?.addEventListener('click', () => handleConnectEvm('MetaMask'));
  document.getElementById('walletOptRabby')?.addEventListener('click', () => handleConnectEvm('Rabby'));
  document.getElementById('walletOptCoinbase')?.addEventListener('click', () => handleConnectEvm('Coinbase'));
  document.getElementById('walletOptPhantom')?.addEventListener('click', () => handleConnectSolana());
  document.getElementById('walletOptSolflare')?.addEventListener('click', () => handleConnectSolana());

  document.getElementById('btnDisconnectWallet')?.addEventListener('click', async () => {
    await walletService.disconnect();
    closeAllModals();
  });

  // Copy address in wallet details
  document.getElementById('walletDetailFullAddress')?.addEventListener('click', () => {
    const addr = walletService.getState().address;
    if (addr) {
      navigator.clipboard.writeText(addr);
      const el = document.getElementById('walletDetailFullAddress');
      if (el) {
        const orig = el.innerHTML;
        el.innerHTML = 'Copied to Clipboard! ✓';
        setTimeout(() => (el.innerHTML = orig), 1800);
      }
    }
  });

  // Switch EVM chain buttons
  document.querySelectorAll('.chain-switch-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const target = btn.getAttribute('data-evm-chain');
      if (target) {
        try {
          await walletService.switchEvmChain(target);
        } catch (err: any) {
          alert('Could not switch chain: ' + (err.message || err));
        }
      }
    });
  });

  // Auth form submissions & tabs
  document.getElementById('btnGoogleAuth')?.addEventListener('click', async () => {
    try {
      await loginWithGoogle();
      closeAllModals();
      navigateToDashboard();
    } catch (err: any) {
      showAuthError(err.message || 'Google Sign-in failed. Please try again.');
    }
  });

  let authMode: 'signin' | 'signup' = 'signin';
  const tabSignIn = document.getElementById('tabSignIn');
  const tabSignUp = document.getElementById('tabSignUp');
  const btnSubmitEmailAuth = document.getElementById('btnSubmitEmailAuth');

  tabSignIn?.addEventListener('click', () => {
    authMode = 'signin';
    tabSignIn.classList.add('is-active');
    tabSignUp?.classList.remove('is-active');
    if (btnSubmitEmailAuth) btnSubmitEmailAuth.textContent = 'Sign In to LedgerGuard';
  });

  tabSignUp?.addEventListener('click', () => {
    authMode = 'signup';
    tabSignUp.classList.add('is-active');
    tabSignIn?.classList.remove('is-active');
    if (btnSubmitEmailAuth) btnSubmitEmailAuth.textContent = 'Create Verified Account';
  });

  document.getElementById('emailAuthForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = (document.getElementById('authEmailInput') as HTMLInputElement)?.value.trim();
    const pass = (document.getElementById('authPasswordInput') as HTMLInputElement)?.value;
    if (!email || !pass) return;

    try {
      if (authMode === 'signin') {
        await loginWithEmail(email, pass);
      } else {
        await registerWithEmail(email, pass);
      }
      closeAllModals();
      navigateToDashboard();
    } catch (err: any) {
      let msg = err.message || 'Authentication failed';
      if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password. Please verify your credentials.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'An account already exists with this email. Please sign in instead.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      }
      showAuthError(msg);
    }
  });

  document.getElementById('btnLogoutUser')?.addEventListener('click', async () => {
    await logoutUser();
    closeAllModals();
    navigateToLanding();
  });

  // Watchlist & Audit drawer tabs
  const tabWatchlist = document.getElementById('tabWatchlist');
  const tabAuditHistory = document.getElementById('tabAuditHistory');
  const watchlistTabContent = document.getElementById('watchlistTabContent');
  const auditHistoryTabContent = document.getElementById('auditHistoryTabContent');

  tabWatchlist?.addEventListener('click', () => {
    tabWatchlist.classList.add('is-active');
    tabAuditHistory?.classList.remove('is-active');
    if (watchlistTabContent) watchlistTabContent.style.display = 'block';
    if (auditHistoryTabContent) auditHistoryTabContent.style.display = 'none';
  });

  tabAuditHistory?.addEventListener('click', () => {
    tabAuditHistory.classList.add('is-active');
    tabWatchlist?.classList.remove('is-active');
    if (watchlistTabContent) watchlistTabContent.style.display = 'none';
    if (auditHistoryTabContent) auditHistoryTabContent.style.display = 'block';
  });

  // Chart Controls
  document.querySelectorAll('.tf-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tf-btn').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      const tf = btn.getAttribute('data-tf') as Timeframe;
      if (activeChartController && tf) {
        activeChartController.setTimeframe(tf);
      }
    });
  });

  document.getElementById('btnModeCandles')?.addEventListener('click', () => {
    document.getElementById('btnModeCandles')?.classList.add('is-active');
    document.getElementById('btnModeArea')?.classList.remove('is-active');
    activeChartController?.setMode('candles');
  });

  document.getElementById('btnModeArea')?.addEventListener('click', () => {
    document.getElementById('btnModeArea')?.classList.add('is-active');
    document.getElementById('btnModeCandles')?.classList.remove('is-active');
    activeChartController?.setMode('area');
  });

  // Star Watchlist toggle inside Chart Modal
  document.getElementById('btnToggleChartWatchlist')?.addEventListener('click', async () => {
    if (!currentUser) {
      openAuthModal();
      return;
    }
    if (!activePairForModal) return;

    const existingIndex = currentWatchlist.findIndex(
      (w) => w.pairAddress.toLowerCase() === (activePairForModal.pairAddress || '').toLowerCase()
    );

    if (existingIndex >= 0) {
      await removeFromWatchlist(currentUser.uid, currentWatchlist[existingIndex].id);
    } else {
      await addToWatchlist(currentUser.uid, {
        pairAddress: activePairForModal.pairAddress || 'unknown',
        chainId: activePairForModal.chainId || 'unknown',
        baseTokenSymbol: activePairForModal.baseToken?.symbol || 'TOKEN',
        baseTokenName: activePairForModal.baseToken?.name,
        priceUsd: String(activePairForModal.priceUsd || '0'),
        liquidityUsd: activePairForModal.liquidity?.usd || 0,
        riskScore: activePairForModal.score || 95,
        isHoneypot: (activePairForModal.score || 95) < 50,
      });
    }
    updateChartModalWatchlistStar();
  });

  // Copy contract inside Chart Modal
  document.getElementById('chartContractCopy')?.addEventListener('click', () => {
    if (activePairForModal?.baseToken?.address) {
      navigator.clipboard.writeText(activePairForModal.baseToken.address);
      const el = document.getElementById('chartContractCopy');
      if (el) {
        const orig = el.innerHTML;
        el.innerHTML = 'Contract Copied! ✓';
        setTimeout(() => (el.innerHTML = orig), 1800);
      }
    }
  });

  // Close modals on overlay backdrop
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        closeAllModals();
      }
    });
  });
}

function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach((m) => m.classList.remove('is-active'));
  document.body.style.overflow = '';
}

function closeProChartModal() {
  const modal = document.getElementById('modalProChart');
  modal?.classList.remove('is-active');
  document.body.style.overflow = '';
  if (activeChartController) {
    activeChartController.destroy();
    activeChartController = null;
  }
}

function showAuthError(msg: string) {
  const el = document.getElementById('authErrorMessage');
  if (el) {
    el.textContent = msg;
    el.style.display = 'block';
  }
}

// ─── AUTH LISTENERS & SYNC ───
function setupAuthListeners() {
  onAuthStateChanged(auth, (user) => {
    currentUser = user;
    const authUserLabel = document.getElementById('authUserLabel');
    const authUserAvatar = document.getElementById('authUserAvatar');
    const mobileAuthUserLabel = document.getElementById('mobileAuthUserLabel');
    const btnHeaderWatchlist = document.getElementById('btnHeaderWatchlist');
    const userProfileEmail = document.getElementById('userProfileEmail');

    if (user) {
      const displayName = user.displayName || user.email?.split('@')[0] || 'Trader';
      if (authUserLabel) authUserLabel.textContent = displayName;
      if (mobileAuthUserLabel) mobileAuthUserLabel.textContent = displayName;
      if (userProfileEmail) userProfileEmail.textContent = user.email || 'Verified Member';
      if (btnHeaderWatchlist) btnHeaderWatchlist.style.display = 'inline-flex';

      if (authUserAvatar) {
        if (user.photoURL) {
          authUserAvatar.innerHTML = `<img src="${user.photoURL}" alt="${displayName}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
        } else {
          authUserAvatar.innerHTML = `<span style="font-size: 11px; font-weight: 800; color: #ffffff;">${displayName.slice(0, 2).toUpperCase()}</span>`;
        }
      }

      // Attach real-time Firestore listeners
      if (unsubscribeWatchlist) unsubscribeWatchlist();
      unsubscribeWatchlist = subscribeUserWatchlist(user.uid, (items) => {
        currentWatchlist = items;
        renderWatchlistUI();
        renderDashboardUI();
        updateChartModalWatchlistStar();
      });

      if (unsubscribeAuditLogs) unsubscribeAuditLogs();
      unsubscribeAuditLogs = subscribeUserAuditLogs(user.uid, (logs) => {
        currentAuditLogs = logs;
        renderAuditHistoryUI();
        renderDashboardUI();
      });

      renderDashboardUI();
    } else {
      if (authUserLabel) authUserLabel.textContent = 'Sign In';
      if (mobileAuthUserLabel) mobileAuthUserLabel.textContent = 'Sign In';
      if (btnHeaderWatchlist) btnHeaderWatchlist.style.display = 'none';
      if (authUserAvatar) {
        authUserAvatar.innerHTML = `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;
      }

      currentWatchlist = [];
      currentAuditLogs = [];
      renderWatchlistUI();
      renderAuditHistoryUI();
      renderDashboardUI();

      if (unsubscribeWatchlist) {
        unsubscribeWatchlist();
        unsubscribeWatchlist = null;
      }
      if (unsubscribeAuditLogs) {
        unsubscribeAuditLogs();
        unsubscribeAuditLogs = null;
      }
    }
  });
}

function handleAuthBtnClick() {
  if (currentUser) {
    navigateToDashboard();
  } else {
    openAuthModal();
  }
}

function openAuthModal() {
  closeAllModals();
  const el = document.getElementById('modalAuth');
  const err = document.getElementById('authErrorMessage');
  if (err) err.style.display = 'none';
  el?.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

function openWatchlistDrawer() {
  closeAllModals();
  const el = document.getElementById('modalWatchlistDrawer');
  el?.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

// ─── WALLET LISTENERS & SYNC ───
function setupWalletListeners() {
  walletService.subscribe((state) => {
    updateWalletTopbarUI(state);
    updateWalletDetailsModal(state);
    renderDashboardUI();
  });
}

function updateWalletTopbarUI(state: WalletState) {
  const label = document.getElementById('walletBtnLabel');
  const mobileLabel = document.getElementById('mobileWalletBtnLabel');
  const btn = document.getElementById('btnConnectWallet');

  if (state.isConnected && state.shortAddress) {
    const text = `${state.chainName} · ${state.shortAddress}`;
    if (label) label.textContent = text;
    if (mobileLabel) mobileLabel.textContent = text;
    btn?.classList.add('is-connected');
  } else {
    const defaultLabel = window.innerWidth <= 640 ? 'Connect' : 'Connect Wallet';
    if (label) label.textContent = defaultLabel;
    if (mobileLabel) mobileLabel.textContent = 'Connect Wallet';
    btn?.classList.remove('is-connected');
  }
}

function updateWalletDetailsModal(state: WalletState) {
  const netTitle = document.getElementById('walletConnectedNetTitle');
  const name = document.getElementById('walletDetailName');
  const chainPill = document.getElementById('walletDetailChainPill');
  const fullAddr = document.getElementById('walletDetailFullAddress');
  const balance = document.getElementById('walletDetailBalance');
  const evmSwitchBlock = document.getElementById('evmChainSwitchBlock');

  if (netTitle) netTitle.textContent = `Active on ${state.chainName || 'Blockchain'}`;
  if (name) name.textContent = state.walletName || 'Web3 Wallet';
  if (chainPill) chainPill.textContent = state.chainName || 'EVM';
  if (fullAddr) fullAddr.innerHTML = `${state.address || '0x...'} <span>📋</span>`;
  if (balance) balance.textContent = `${state.balance || '0.0000'} ${state.balanceSymbol}`;

  if (evmSwitchBlock) {
    evmSwitchBlock.style.display = state.chainType === 'evm' ? 'block' : 'none';
  }
}

function handleWalletBtnClick() {
  const state = walletService.getState();
  if (state.isConnected) {
    closeAllModals();
    document.getElementById('modalWalletDetails')?.classList.add('is-active');
    document.body.style.overflow = 'hidden';
  } else {
    openWalletSelectorModal();
  }
}

function openWalletSelectorModal() {
  closeAllModals();
  const avail = walletService.getAvailableWallets();

  // Update statuses
  const statusMetaMask = document.getElementById('statusMetaMask');
  const statusRabby = document.getElementById('statusRabby');
  const statusCoinbase = document.getElementById('statusCoinbase');
  const statusPhantom = document.getElementById('statusPhantom');
  const statusSolflare = document.getElementById('statusSolflare');

  if (statusMetaMask) statusMetaMask.textContent = avail.hasMetaMask ? 'Detected ✓' : 'Install Extension';
  if (statusRabby) statusRabby.textContent = avail.hasRabby ? 'Detected ✓' : 'Install Extension';
  if (statusCoinbase) statusCoinbase.textContent = avail.hasCoinbase ? 'Detected ✓' : 'Install Extension';
  if (statusPhantom) statusPhantom.textContent = avail.hasPhantom ? 'Detected ✓' : 'Install Extension';
  if (statusSolflare) statusSolflare.textContent = avail.hasSolflare ? 'Detected ✓' : 'Install Extension';

  const err = document.getElementById('walletErrorAlert');
  if (err) err.style.display = 'none';

  document.getElementById('modalWalletSelector')?.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

async function handleConnectEvm(walletChoice: string) {
  const errBox = document.getElementById('walletErrorAlert');
  try {
    if (errBox) errBox.style.display = 'none';
    await walletService.connectEvm();
    closeAllModals();
  } catch (err: any) {
    if (errBox) {
      errBox.textContent = err.message || `Failed to connect ${walletChoice}. Ensure your wallet extension is unlocked.`;
      errBox.style.display = 'block';
    }
  }
}

async function handleConnectSolana() {
  const errBox = document.getElementById('walletErrorAlert');
  try {
    if (errBox) errBox.style.display = 'none';
    await walletService.connectSolana();
    closeAllModals();
  } catch (err: any) {
    if (errBox) {
      errBox.textContent = err.message || 'Failed to connect Solana wallet. Ensure Phantom or Solflare is installed.';
      errBox.style.display = 'block';
    }
  }
}

// ─── WATCHLIST & AUDIT LOGS UI RENDERING ───
function renderWatchlistUI() {
  const headerCount = document.getElementById('headerWatchlistCount');
  const tabCount = document.getElementById('countWatchlistTab');
  const list = document.getElementById('watchlistItemsList');
  const empty = document.getElementById('watchlistEmptyState');

  const count = currentWatchlist.length;
  if (headerCount) headerCount.textContent = String(count);
  if (tabCount) tabCount.textContent = String(count);

  if (!list || !empty) return;

  if (count === 0) {
    list.innerHTML = '';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  list.innerHTML = currentWatchlist.map((item) => `
    <div class="watchlist-card" data-watch-id="${item.id}">
      <div style="flex: 1; min-width: 0;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span class="font-extrabold text-white">$${item.baseTokenSymbol}</span>
          <span class="chain-pill" style="font-size: 11px;">${item.chainId.toUpperCase()}</span>
          <span class="${item.isHoneypot ? 'threat-tag-danger' : 'threat-tag-safe'} font-bold">
            ${item.isHoneypot ? 'Honeypot' : `Score ${item.riskScore || 95}/100`}
          </span>
        </div>
        <div style="font-size: 13px; font-weight: 700; color: #94a3b8; margin-top: 4px;">
          Price: <strong class="text-white">${formatPrice(item.priceUsd)}</strong> · Liq: ${formatUsd(item.liquidityUsd)}
        </div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn-inspect-chart font-bold" data-inspect-pair="${item.pairAddress}">
          Chart
        </button>
        <button class="btn-remove-watch" data-remove-id="${item.id}" title="Remove from Watchlist">
          ✕
        </button>
      </div>
    </div>
  `).join('');

  // Bind actions
  list.querySelectorAll('.btn-remove-watch').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-remove-id');
      if (id && currentUser) {
        await removeFromWatchlist(currentUser.uid, id);
      }
    });
  });

  list.querySelectorAll('.btn-inspect-chart').forEach((btn) => {
    btn.addEventListener('click', () => {
      const pairAddr = btn.getAttribute('data-inspect-pair');
      const item = currentWatchlist.find((w) => w.pairAddress === pairAddr);
      if (item) {
        openProChartModal({
          chainId: item.chainId,
          pairAddress: item.pairAddress,
          baseToken: { symbol: item.baseTokenSymbol, name: item.baseTokenName || item.baseTokenSymbol, address: item.pairAddress },
          priceUsd: item.priceUsd,
          priceChange: { h24: 3.5 },
          volume: { h24: 1200000 },
          liquidity: { usd: item.liquidityUsd },
          score: item.riskScore,
          verdict: item.isHoneypot ? 'Honeypot' : 'Verified Safe',
        });
      }
    });
  });
}

function renderAuditHistoryUI() {
  const tabCount = document.getElementById('countAuditsTab');
  const list = document.getElementById('auditHistoryList');
  const empty = document.getElementById('auditHistoryEmptyState');

  const count = currentAuditLogs.length;
  if (tabCount) tabCount.textContent = String(count);

  if (!list || !empty) return;

  if (count === 0) {
    list.innerHTML = '';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  list.innerHTML = currentAuditLogs.map((log) => `
    <div class="watchlist-card">
      <div style="flex: 1; min-width: 0;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span class="font-extrabold text-white">$${log.tokenSymbol}</span>
          <span class="chain-pill" style="font-size: 11px;">${log.chainId.toUpperCase()}</span>
          <span class="${(log.riskScore || 90) < 50 ? 'threat-tag-danger' : 'threat-tag-safe'} font-bold">
            ${log.honeypotStatus || 'Verified'}
          </span>
        </div>
        <div style="font-size: 12px; font-weight: 700; color: #64748b; margin-top: 4px; font-family: monospace;">
          ${log.contractAddress.slice(0, 16)}... · ${new Date(log.auditedAt).toLocaleDateString()}
        </div>
      </div>
    </div>
  `).join('');
}

function updateChartModalWatchlistStar() {
  if (!activePairForModal) return;
  const starIcon = document.getElementById('starIcon');
  const starLabel = document.getElementById('starLabel');
  const btn = document.getElementById('btnToggleChartWatchlist');

  const isSaved = currentWatchlist.some(
    (w) => w.pairAddress.toLowerCase() === (activePairForModal.pairAddress || '').toLowerCase()
  );

  if (isSaved) {
    if (starIcon) starIcon.textContent = '★';
    if (starLabel) starLabel.textContent = 'Saved';
    btn?.classList.add('is-active');
  } else {
    if (starIcon) starIcon.textContent = '☆';
    if (starLabel) starLabel.textContent = 'Watch';
    btn?.classList.remove('is-active');
  }
}

// ─── PRO TRADINGVIEW CHART MODAL OPEN ───
export function openProChartModal(pair: any) {
  closeAllModals();
  activePairForModal = pair;

  const modal = document.getElementById('modalProChart');
  const host = document.getElementById('chartCanvasHost');
  if (!modal || !host) return;

  // Clean previous chart instance
  if (activeChartController) {
    activeChartController.destroy();
    activeChartController = null;
  }
  host.innerHTML = '';

  // Populate token metadata
  const symbol = pair.baseToken?.symbol || 'TOKEN';
  const name = pair.baseToken?.name || symbol;
  const contractAddr = pair.baseToken?.address || pair.pairAddress || '0x...';
  const isEvm = contractAddr.startsWith('0x');
  const chain = pair.chainId || (isEvm ? 'ethereum' : 'solana');
  const price = parseFloat(pair.priceUsd) || 0.0001;
  const change = pair.priceChange?.h24 ?? 0;
  const vol = pair.volume?.h24 || 1000000;
  const liq = pair.liquidity?.usd || 500000;
  const score = pair.score || (change > 200 ? 25 : 95);
  const isHoneypot = score < 50;

  document.getElementById('chartTokenSymbol')!.textContent = `$${symbol}`;
  document.getElementById('chartTokenName')!.textContent = name;
  document.getElementById('chartChainPill')!.textContent = chain.toUpperCase();
  document.getElementById('chartDexPill')!.textContent = (pair.dexId || 'DEX').toUpperCase();
  document.getElementById('chartContractCopy')!.innerHTML = `${(pair.baseToken?.address || pair.pairAddress || '0x...').slice(0, 10)}... <span>📋</span>`;

  const verdictEl = document.getElementById('chartSafetyVerdict')!;
  verdictEl.textContent = isHoneypot ? 'HONEYPOT TRAP (GRADE F)' : 'VERIFIED SAFE (GRADE A)';
  verdictEl.className = `font-bold ${isHoneypot ? 'threat-tag-danger' : 'verified-safe-tag'}`;

  // Price & Stats
  document.getElementById('chartPriceUsd')!.textContent = formatPrice(price);
  const chgEl = document.getElementById('chartPriceChange')!;
  chgEl.textContent = `${change >= 0 ? '+' : ''}${Number(change).toFixed(2)}%`;
  chgEl.style.color = change >= 0 ? '#34d399' : '#f87171';
  document.getElementById('chartVol24h')!.textContent = formatUsd(vol);
  document.getElementById('chartLiqUsd')!.textContent = formatUsd(liq);

  // Security Matrix DOM refs
  const hpEl = document.getElementById('chartCardHoneypot')!;
  const authEl = document.getElementById('chartCardAuthorities')!;
  const liqEl = document.getElementById('chartCardLiquidity')!;
  const whaleEl = document.getElementById('chartCardWhales')!;
  const ownerEl = document.getElementById('chartCardOwnership')!;
  const provEl = document.getElementById('chartProviderBadge')!;
  const flagsBox = document.getElementById('chartThreatFlagsBox')!;
  const flagsList = document.getElementById('chartThreatFlagsList')!;

  hpEl.textContent = 'Probing Bytecode...';
  hpEl.style.color = '#cbd5e1';
  authEl.textContent = 'Checking Authorities...';
  authEl.style.color = '#cbd5e1';
  liqEl.textContent = 'Verifying Locks...';
  liqEl.style.color = '#cbd5e1';
  whaleEl.textContent = 'Analyzing Wallets...';
  whaleEl.style.color = '#cbd5e1';
  ownerEl.textContent = 'Checking Ownership...';
  ownerEl.style.color = '#cbd5e1';
  if (flagsBox) flagsBox.style.display = 'none';
  if (flagsList) flagsList.innerHTML = '';

  // Asynchronously query live GoPlus or RugCheck data through server proxy
  scanTokenSecurity(contractAddr, chain).then((report) => {
    if (!report) return;

    // Provider tag
    if (provEl) {
      if (report.provider === 'goplus') {
        provEl.textContent = 'Mainnet Security Verified';
        provEl.style.color = '#38bdf8';
      } else if (report.provider === 'rugcheck') {
        provEl.textContent = 'On-Chain Solana Verified';
        provEl.style.color = '#c084fc';
      } else {
        provEl.textContent = 'Bytecode Verified';
        provEl.style.color = '#94a3b8';
      }
    }

    // Verdict tag
    if (verdictEl) {
      verdictEl.textContent = `${report.verdict} (${report.score}/100)`;
      verdictEl.className = `font-bold ${report.score >= 80 ? 'verified-safe-tag' : report.score >= 50 ? 'threat-tag-warning' : 'threat-tag-danger'}`;
    }

    // 1. Honeypot & Tax
    if (report.isHoneypot || report.cannotSell) {
      hpEl.textContent = `Honeypot Trap (${report.sellTax}% Sell Tax)`;
      hpEl.style.color = '#f87171';
    } else {
      hpEl.textContent = `Clean (Buy ${report.buyTax}% · Sell ${report.sellTax}%)`;
      hpEl.style.color = '#34d399';
    }

    // 2. Mint & Freeze Authorities
    if (report.mintAuthorityRevoked && report.freezeAuthorityRevoked) {
      authEl.textContent = 'Mint & Freeze Revoked ✓';
      authEl.style.color = '#34d399';
    } else {
      authEl.textContent = `${!report.mintAuthorityRevoked ? 'Mint Active ⚠ ' : ''}${!report.freezeAuthorityRevoked ? 'Freeze Active ⚠' : ''}`;
      authEl.style.color = '#f87171';
    }

    // 3. LP Lock Status
    if (report.lpLockedPercent >= 80) {
      liqEl.textContent = `${report.lpLockedPercent}% Locked / Burned`;
      liqEl.style.color = '#34d399';
    } else {
      liqEl.textContent = `${report.lpLockedPercent}% Locked (Rug Risk)`;
      liqEl.style.color = '#f87171';
    }

    // 4. Whale Concentration
    if (whaleEl) {
      whaleEl.textContent = `Top 10: ${report.top10HoldersShare}% Supply`;
      whaleEl.style.color = report.top10HoldersShare > 60 ? '#f59e0b' : '#34d399';
    }

    // 5. Ownership State
    if (ownerEl) {
      ownerEl.textContent = report.ownershipRenounced ? 'Ownership Renounced ✓' : 'Owner Privileges Active';
      ownerEl.style.color = report.ownershipRenounced ? '#34d399' : '#f59e0b';
    }

    // 6. Threat Flags
    if (report.flags && report.flags.length > 0 && flagsBox && flagsList) {
      flagsList.innerHTML = '';
      report.flags.forEach((f) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${f.title}</strong>: ${f.description}`;
        li.style.color = f.level === 'danger' ? '#fca5a5' : '#fde68a';
        flagsList.appendChild(li);
      });
      flagsBox.style.display = 'block';
    } else if (flagsBox) {
      flagsBox.style.display = 'none';
    }

    // 7. Real Gemini 2.5 AI Security Auditor (Live API)
    requestAiSecurityAudit({
      tokenSymbol: symbol,
      tokenName: name,
      chain,
      address: contractAddr,
      riskScore: report.score,
      buyTax: report.buyTax,
      sellTax: report.sellTax,
      isHoneypot: report.isHoneypot,
      mintRevoked: report.mintAuthorityRevoked,
      freezeRevoked: report.freezeAuthorityRevoked,
    }).then((aiResult) => {
      if (!aiResult || !flagsBox || !flagsList) return;
      const aiCard = document.createElement('li');
      aiCard.className = 'gemini-ai-audit-card';
      aiCard.style.cssText = 'background: rgba(192, 132, 252, 0.08); border: 1px solid rgba(192, 132, 252, 0.35); border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; list-style: none;';
      aiCard.innerHTML = `
        <div style="font-weight: 800; color: #c084fc; margin-bottom: 4px; display: flex; align-items: center; justify-content: space-between;">
          <span style="display: flex; align-items: center; gap: 6px;"><span>Gemini 2.5 Flash AI Auditor</span></span>
          <span style="font-size: 11px; padding: 2px 7px; border-radius: 999px; background: rgba(192, 132, 252, 0.22); color: #f3e8ff; font-weight: 800;">${aiResult.riskLevel} RISK</span>
        </div>
        <p style="font-size: 12.5px; color: #e2e8f0; margin-bottom: 6px; line-height: 1.45;">${aiResult.summary}</p>
        <div style="font-size: 12px; color: #a5f3fc; font-weight: 600;"><strong>Actionable Verdict:</strong> ${aiResult.recommendation}</div>
      `;
      flagsList.prepend(aiCard);
      flagsBox.style.display = 'block';
    });

    // Record verified audit log in user's Firebase account if signed in
    if (currentUser) {
      recordAuditLog(currentUser.uid, {
        contractAddress: contractAddr,
        chainId: chain,
        tokenName: name,
        tokenSymbol: symbol,
        riskScore: report.score,
        honeypotStatus: report.isHoneypot ? 'Honeypot Trap' : 'Verified Safe',
        liquidityScore: report.lpLockedPercent,
      }).catch((err) => console.warn('Could not record audit log:', err));
    }
  });

  // Crosshair HUD refs
  const hudOpen = document.getElementById('hudOpen')!;
  const hudHigh = document.getElementById('hudHigh')!;
  const hudLow = document.getElementById('hudLow')!;
  const hudClose = document.getElementById('hudClose')!;
  const hudVol = document.getElementById('hudVol')!;
  const hudChg = document.getElementById('hudChg')!;

  // Mount TradingView Lightweight Chart
  activeChartController = new TokenChartController({
    container: host,
    symbol,
    name,
    currentPrice: price,
    change24h: change,
    volume24h: vol,
    onCrosshairMove: (data) => {
      if (data) {
        hudOpen.textContent = data.open !== undefined ? formatPrice(data.open) : '-';
        hudHigh.textContent = data.high !== undefined ? formatPrice(data.high) : '-';
        hudLow.textContent = data.low !== undefined ? formatPrice(data.low) : '-';
        hudClose.textContent = formatPrice(data.close);
        hudVol.textContent = data.volume !== undefined ? formatUsd(data.volume) : '-';
        if (data.changePercent !== undefined) {
          hudChg.textContent = `${data.changePercent >= 0 ? '+' : ''}${data.changePercent.toFixed(2)}%`;
          hudChg.style.color = data.changePercent >= 0 ? '#34d399' : '#f87171';
        }
      } else {
        hudOpen.textContent = '-';
        hudHigh.textContent = '-';
        hudLow.textContent = '-';
        hudClose.textContent = formatPrice(price);
        hudVol.textContent = formatUsd(vol);
        hudChg.textContent = `${change >= 0 ? '+' : ''}${Number(change).toFixed(2)}%`;
        hudChg.style.color = change >= 0 ? '#34d399' : '#f87171';
      }
    },
  });

  // Default mode & timeframe UI sync
  document.querySelectorAll('.tf-btn').forEach((b) => b.classList.remove('is-active'));
  document.querySelector('.tf-btn[data-tf="15m"]')?.classList.add('is-active');

  document.getElementById('btnModeCandles')?.classList.add('is-active');
  document.getElementById('btnModeArea')?.classList.remove('is-active');

  updateChartModalWatchlistStar();

  modal.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

// ─── HOOK DEX SCREENER ROWS & HERO CHIPS ───
function hookDexScreenerEvents() {
  // Global click delegator for chart open
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;

    // "Chart" or "Audit" button clicked in DEX table
    const auditBtn = target.closest('.btn-audit-row') as HTMLElement;
    if (auditBtn) {
      const pairJson = auditBtn.getAttribute('data-pair');
      if (pairJson) {
        try {
          const pair = JSON.parse(decodeURIComponent(pairJson));
          openProChartModal(pair);
        } catch {}
      }
      return;
    }

    // Quick token chip click
    const chip = target.closest('.token-chip[data-token]') as HTMLElement;
    if (chip) {
      const tok = chip.getAttribute('data-token');
      if (!tok) return;
      if (tok === 'scam') {
        openProChartModal({
          chainId: 'solana',
          dexId: 'raydium',
          pairAddress: 'fake99...ray',
          baseToken: { name: 'MoonPump Ape', symbol: 'FAKERUG', address: '0x39a1f72c3d8246a482b819f39bb73a0091d39218' },
          priceUsd: '0.00000014',
          priceChange: { h24: 480.0 },
          volume: { h24: 124000 },
          liquidity: { usd: 3400 },
          score: 16,
          verdict: 'Honeypot 99% Tax',
        });
      } else {
        openProChartModal({
          chainId: tok === 'pepe' ? 'ethereum' : 'solana',
          dexId: tok === 'pepe' ? 'uniswap' : 'raydium',
          pairAddress: `0x${tok}pooladdress`,
          baseToken: {
            name: tok.toUpperCase(),
            symbol: tok.toUpperCase(),
            address: `0x${tok}contractaddress123456789`,
          },
          priceUsd: tok === 'pepe' ? '0.00000421' : tok === 'bonk' ? '0.0000185' : '0.542',
          priceChange: { h24: tok === 'wif' ? -3.14 : 4.8 },
          volume: { h24: 14500000 },
          liquidity: { usd: 18900000 },
          score: 95,
          verdict: 'Verified Safe',
        });
      }
    }
  });

  // Expose to window so existing inline DEX renderer can trigger pro chart modal
  (window as any).openProChartModal = openProChartModal;
}

// ═══════════════════════════════════════════════════════════
// ENTERPRISE WEB3 SECURITY DASHBOARD CONTROLLER & ROUTING
// ═══════════════════════════════════════════════════════════

export function setupRoutingAndViews() {
  window.addEventListener('hashchange', () => {
    handleHashRoute();
  });

  // Direct nav links
  document.getElementById('navDashboardLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    navigateToDashboard();
  });

  document.getElementById('drawerDashboardLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('mobileDrawer')?.classList.remove('is-open');
    navigateToDashboard();
  });

  // Initial route inspection
  handleHashRoute();
}

function handleHashRoute() {
  const hash = window.location.hash.toLowerCase();
  if (hash.startsWith('#dashboard')) {
    showDashboardView();
  } else {
    showLandingView();
  }
}

export function showDashboardView() {
  const landing = document.getElementById('landingView');
  const dash = document.getElementById('dashboardView');
  if (landing) landing.style.display = 'none';
  if (dash) dash.style.display = 'block';

  window.scrollTo({ top: 0, behavior: 'smooth' });
  renderDashboardUI();
}

export function showLandingView() {
  const landing = document.getElementById('landingView');
  const dash = document.getElementById('dashboardView');
  if (landing) landing.style.display = 'block';
  if (dash) dash.style.display = 'none';
}

export function navigateToDashboard() {
  window.location.hash = '#dashboard';
  showDashboardView();
}

export function navigateToLanding() {
  window.location.hash = '#/';
  showLandingView();
}

// Global window exposure for inline elements
(window as any).navigateToDashboard = navigateToDashboard;
(window as any).navigateToLanding = navigateToLanding;
(window as any).showDashboardView = showDashboardView;
(window as any).showLandingView = showLandingView;

// ─── FITONIST DASHBOARD REACTIVE RENDERER ───
export function renderDashboardUI() {
  // 1. User Identity in Fitonist Topbar
  const userNameEl = document.getElementById('fitUserName');
  const userEmailEl = document.getElementById('fitUserEmail');
  const userAvatarEl = document.getElementById('fitUserAvatar');

  if (currentUser) {
    const displayName = currentUser.displayName || currentUser.email?.split('@')[0] || 'Olivia Brooks';
    const email = currentUser.email || 'admin2@ftn.net';
    if (userNameEl) userNameEl.textContent = displayName;
    if (userEmailEl) userEmailEl.textContent = email;

    if (userAvatarEl) {
      if (currentUser.photoURL) {
        userAvatarEl.innerHTML = `<img src="${currentUser.photoURL}" alt="${displayName}" style="width: 100%; height: 100%; object-fit: cover;">`;
      } else {
        const initials = displayName.slice(0, 2).toUpperCase();
        userAvatarEl.innerHTML = `<span>${initials}</span>`;
      }
    }
  } else {
    if (userNameEl) userNameEl.textContent = 'Guest Trader';
    if (userEmailEl) userEmailEl.textContent = 'Sign in to sync your Cloud Watchlist';
    if (userAvatarEl) userAvatarEl.innerHTML = `<span>GT</span>`;
  }

  // 2. Render Monitored Contracts / Popular Workouts (Clean Zero-State Guarantee)
  renderFitonistWorkoutsList();

  // 3. Count-up Animation with easeOutCubic
  initDashboardCountUps();
}

let hasCountedUp = false;
function initDashboardCountUps() {
  const countElements = [
    { id: 'statInferenceTime', target: 120, decimals: 0, suffix: 'ms' },
    { id: 'statUptime', target: 99.99, decimals: 2, suffix: '%' },
    { id: 'statRuntime', target: 24, decimals: 0, suffix: '/7' },
    { id: 'statContext', target: 2.4, decimals: 1, suffix: 'M' },
  ];

  countElements.forEach((item, i) => {
    const el = document.getElementById(item.id);
    if (!el) return;

    const startOffset = 480 + i * 90;
    const duration = 1500 + i * 80;

    setTimeout(() => {
      const startTime = performance.now();
      function update(currentTime: number) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(1, elapsed / duration);
        // easeOutCubic
        const ease = 1 - Math.pow(1 - progress, 3);
        const currentVal = (item.target * ease).toFixed(item.decimals);
        el!.innerHTML = `${currentVal}<span class="fit-stat-suffix">${item.suffix}</span>`;

        if (progress < 1) {
          requestAnimationFrame(update);
        }
      }
      requestAnimationFrame(update);
    }, startOffset);
  });
}

function renderFitonistWorkoutsList() {
  const container = document.getElementById('fitWorkoutsList');
  if (!container) return;

  // Strict User Directive: "no predetails will be there like when user redirect he should not see that these messages are there but I didn't send it"
  if (currentWatchlist.length === 0) {
    container.innerHTML = `
      <div class="fit-zero-state">
        <div class="fit-zero-icon">⭐</div>
        <div class="fit-zero-title">Your Watchlist is Clean</div>
        <p class="fit-zero-text">No pre-populated items. Scan any token or click below to track live liquidity and threat scores.</p>
        <button class="fit-btn-add-token font-bold" id="btnFitQuickAddSample">
          + Track Recommended Token
        </button>
      </div>
    `;

    document.getElementById('btnFitQuickAddSample')?.addEventListener('click', async () => {
      if (!currentUser) {
        openAuthModal();
        return;
      }
      await addToWatchlist(currentUser.uid, {
        pairAddress: '0xa43fe1690fb5055b73983c2e177b963e0026e632',
        chainId: 'ethereum',
        baseTokenSymbol: 'PEPE',
        baseTokenName: 'Pepe',
        priceUsd: '0.0000094',
        liquidityUsd: 14500000,
        riskScore: 98,
        isHoneypot: false,
      });
    });
    return;
  }

  // Render authentic user-added tokens
  container.innerHTML = currentWatchlist.map((item, idx) => {
    const isSafe = (item.riskScore || 95) >= 75;
    const tagClass = isSafe ? 'green' : 'amber';
    const tagText = isSafe ? 'Verified Safe' : 'Honeypot Trap';
    const volStr = item.liquidityUsd ? formatUsd(item.liquidityUsd).replace('$', '') : '39k';
    const icons = ['🛡️', '⚡', '💎', '🔥', '🪙'];
    const icon = icons[idx % icons.length];

    return `
      <div class="fit-workout-row" data-watch-id="${item.id}" data-pair="${item.pairAddress}">
        <div class="fit-workout-left">
          <div class="fit-workout-thumb">${icon}</div>
          <div class="fit-workout-meta">
            <span class="fit-workout-name">$${item.baseTokenSymbol} (${item.baseTokenName || item.baseTokenSymbol})</span>
            <span class="fit-workout-tag ${tagClass}">${tagText} · ${item.chainId.toUpperCase()}</span>
          </div>
        </div>
        <div class="fit-workout-metric">${volStr}</div>
      </div>
    `;
  }).join('');

  // Row click opens deep Pro Chart modal
  container.querySelectorAll('.fit-workout-row').forEach((row) => {
    row.addEventListener('click', () => {
      const pairAddr = row.getAttribute('data-pair');
      const item = currentWatchlist.find((w) => w.pairAddress === pairAddr);
      if (item) {
        openProChartModal({
          chainId: item.chainId,
          pairAddress: item.pairAddress,
          baseToken: { symbol: item.baseTokenSymbol, name: item.baseTokenName || item.baseTokenSymbol, address: item.pairAddress },
          priceUsd: item.priceUsd,
          priceChange: { h24: 3.8 },
          volume: { h24: 14500000 },
          liquidity: { usd: item.liquidityUsd },
          score: item.riskScore,
          verdict: item.isHoneypot ? 'Honeypot' : 'Verified Safe',
        });
      }
    });
  });
}

// ─── OBSIDIAN DASHBOARD CONTROLLER (BUYER & MAKER ENGINE) ───
export function setupDashboardEventListeners() {
  // 1. Mode Switcher (Buyer Mode vs. Maker Mode)
  const btnBuyer = document.getElementById('dashBtnBuyerMode');
  const btnMaker = document.getElementById('dashBtnMakerMode');
  const buyerView = document.getElementById('dashBuyerView');
  const makerView = document.getElementById('dashMakerView');

  const switchMode = (mode: 'buyer' | 'maker') => {
    if (mode === 'buyer') {
      btnBuyer?.classList.add('is-active');
      btnMaker?.classList.remove('is-active');
      if (buyerView) buyerView.style.display = 'block';
      if (makerView) makerView.style.display = 'none';
    } else {
      btnMaker?.classList.add('is-active');
      btnBuyer?.classList.remove('is-active');
      if (buyerView) buyerView.style.display = 'none';
      if (makerView) makerView.style.display = 'block';
    }
  };

  btnBuyer?.addEventListener('click', () => switchMode('buyer'));
  btnMaker?.addEventListener('click', () => switchMode('maker'));

  // 2. Return to Landing
  document.getElementById('btnFitReturnLanding')?.addEventListener('click', (e) => {
    e.preventDefault();
    navigateToLanding();
  });

  // 3. User Sign Out (Clean state guarantee — no fake predetails)
  document.getElementById('btnDashSignOut')?.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    await logoutUser();
    navigateToLanding();
  });

  // 4. DexScreener Pro Portable Toolbar & Viewport Controls
  const dexContainer = document.getElementById('dashDexContainer');
  const dexEmbed = document.getElementById('dashDexEmbed') as HTMLIFrameElement | null;
  const btnMaximize = document.getElementById('btnMaximizeDexChart');
  const btnFloatingExit = document.getElementById('btnExitFloatingFullscreen');
  const iconMax = document.getElementById('iconDexMaximize');
  const iconRestore = document.getElementById('iconDexRestore');
  const lblMax = document.getElementById('lblDexMaximize');

  // Fullscreen / Window Maximize Toggle
  const toggleDexFullscreen = () => {
    if (!dexContainer) return;
    const isMax = dexContainer.classList.toggle('is-maximized');
    if (iconMax) iconMax.style.display = isMax ? 'none' : 'block';
    if (iconRestore) iconRestore.style.display = isMax ? 'block' : 'none';
    if (lblMax) lblMax.textContent = isMax ? 'Restore' : 'Expand';
    document.body.style.overflow = isMax ? 'hidden' : '';
    if (activeNativeChart) {
      setTimeout(() => {
        // Trigger resize on canvas
        window.dispatchEvent(new Event('resize'));
      }, 100);
    }
  };

  btnMaximize?.addEventListener('click', toggleDexFullscreen);
  btnFloatingExit?.addEventListener('click', toggleDexFullscreen);
  document.getElementById('btnDexSysMax')?.addEventListener('click', toggleDexFullscreen);

  // Height Mode Presets (Compact / Standard / Expanded)
  document.querySelectorAll('.dex-tool-btn[data-set-height]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.dex-tool-btn[data-set-height]').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      const hMode = btn.getAttribute('data-set-height') || 'standard';
      dexContainer?.setAttribute('data-height-mode', hMode);
      setTimeout(() => window.dispatchEvent(new Event('resize')), 150);
    });
  });

  // Cycle height with amber traffic light
  document.getElementById('btnDexSysMin')?.addEventListener('click', () => {
    const cur = dexContainer?.getAttribute('data-height-mode') || 'standard';
    const next = cur === 'compact' ? 'standard' : cur === 'standard' ? 'expanded' : 'compact';
    dexContainer?.setAttribute('data-height-mode', next);
    document.querySelectorAll('.dex-tool-btn[data-set-height]').forEach((b) => {
      if (b.getAttribute('data-set-height') === next) b.classList.add('is-active');
      else b.classList.remove('is-active');
    });
    setTimeout(() => window.dispatchEvent(new Event('resize')), 150);
  });

  // Reset to default with red traffic light
  document.getElementById('btnDexSysClose')?.addEventListener('click', () => {
    startLiveCoinResearch('0xa43fe16908251ee70ef74718545e4fe6c5ccec9f', 'ethereum');
  });

  // ─── MULTI-ENGINE CHART SWITCHER (DexScreener, GeckoTerminal, Native Canvas) ───
  document.querySelectorAll('.dex-engine-btn[data-engine], .chart-big-option-card[data-engine]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const engine = btn.getAttribute('data-engine') as 'dexscreener' | 'geckoterminal' | 'native';
      if (engine) switchDashboardChartEngine(engine);
    });
  });

  // Recovery veil buttons
  document.getElementById('btnRecoverNative')?.addEventListener('click', () => {
    switchDashboardChartEngine('native');
  });

  document.getElementById('btnRecoverGecko')?.addEventListener('click', () => {
    switchDashboardChartEngine('geckoterminal');
  });

  document.getElementById('btnReportConnectionIssue')?.addEventListener('click', () => {
    const banner = document.getElementById('dashDexConnectionErrorBanner');
    if (banner) {
      banner.style.display = banner.style.display === 'none' ? 'flex' : 'none';
    }
  });

  // Native Chart Subbar Timeframe & Mode Controls
  document.querySelectorAll('.dash-tf-btn[data-native-tf]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.dash-tf-btn[data-native-tf]').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      const tf = btn.getAttribute('data-native-tf') as Timeframe;
      if (activeNativeChart && tf) {
        activeNativeChart.setTimeframe(tf);
      }
    });
  });

  document.getElementById('btnDashModeCandles')?.addEventListener('click', () => {
    document.getElementById('btnDashModeCandles')?.classList.add('is-active');
    document.getElementById('btnDashModeArea')?.classList.remove('is-active');
    activeNativeChart?.setMode('candles');
  });

  document.getElementById('btnDashModeArea')?.addEventListener('click', () => {
    document.getElementById('btnDashModeArea')?.classList.add('is-active');
    document.getElementById('btnDashModeCandles')?.classList.remove('is-active');
    activeNativeChart?.setMode('area');
  });

  // Reload Iframe or Canvas (R)
  const reloadDexChart = () => {
    if (currentChartEngine === 'native') {
      mountNativeTradingViewChart();
    } else if (dexEmbed) {
      const currentSrc = dexEmbed.src;
      dexEmbed.src = '';
      setTimeout(() => {
        dexEmbed.src = currentSrc;
      }, 80);
    }
  };
  document.getElementById('btnReloadDexChart')?.addEventListener('click', reloadDexChart);

  // Toggle Trades / Info Panel (info=0 vs info=1)
  const btnToggleInfo = document.getElementById('btnToggleDexInfo');
  btnToggleInfo?.addEventListener('click', () => {
    currentDexInfoMode = !currentDexInfoMode;
    btnToggleInfo.classList.toggle('is-active', currentDexInfoMode);
    if (currentChartEngine === 'dexscreener' && dexEmbed && currentActivePairAddress) {
      dexEmbed.src = `https://dexscreener.com/${currentActiveChainId}/${currentActivePairAddress}?embed=1&theme=dark&info=${currentDexInfoMode ? '1' : '0'}`;
    }
  });

  // Copy Pair Contract Button
  const btnCopyContract = document.getElementById('btnCopyDexContract');
  btnCopyContract?.addEventListener('click', () => {
    if (currentActivePairAddress) {
      navigator.clipboard.writeText(currentActivePairAddress);
      const copyText = document.getElementById('copyPairText');
      if (copyText) {
        copyText.textContent = 'Copied! ✓';
        setTimeout(() => {
          if (copyText) copyText.textContent = 'Copy Contract';
        }, 1800);
      }
    }
  });

  // Windows Desktop Keyboard Shortcuts: F (Fullscreen), R (Reload), Esc (Exit)
  window.addEventListener('keydown', (e) => {
    const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

    if (e.key === 'Escape' && dexContainer?.classList.contains('is-maximized')) {
      toggleDexFullscreen();
    } else if (e.key === 'f' || e.key === 'F') {
      const dashView = document.getElementById('dashboardView');
      if (dashView && dashView.classList.contains('is-active')) {
        e.preventDefault();
        toggleDexFullscreen();
      }
    } else if (e.key === 'r' || e.key === 'R') {
      const dashView = document.getElementById('dashboardView');
      if (dashView && dashView.classList.contains('is-active')) {
        e.preventDefault();
        reloadDexChart();
      }
    }
  });

  // 5. Quick Hot Pair Chips
  document.querySelectorAll('.dash-chip-btn[data-hot-symbol]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const sym = btn.getAttribute('data-hot-symbol') || '';
      const chain = btn.getAttribute('data-hot-chain') || 'auto';
      const pair = btn.getAttribute('data-hot-pair') || '';

      const input = document.getElementById('dashResearchInput') as HTMLInputElement | null;
      const select = document.getElementById('dashResearchChain') as HTMLSelectElement | null;
      if (input) input.value = pair || sym;
      if (select) select.value = chain;

      startLiveCoinResearch(pair || sym, chain);
    });
  });

  // 6. Start Deep Research Button & Enter Key
  const researchInput = document.getElementById('dashResearchInput') as HTMLInputElement | null;
  const researchChainSelect = document.getElementById('dashResearchChain') as HTMLSelectElement | null;
  const btnStartResearch = document.getElementById('btnDashStartResearch');

  const triggerResearch = () => {
    const q = researchInput?.value.trim() || '0x6982508145454ce325ddbe47a25d4ec3d2311933';
    const chain = researchChainSelect?.value || 'auto';
    startLiveCoinResearch(q, chain);
  };

  btnStartResearch?.addEventListener('click', triggerResearch);
  researchInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      triggerResearch();
    }
  });

  // 7. Maker Mode Form Submit (AI Master Launch Plan Generator)
  const makerForm = document.getElementById('dashMakerForm');
  makerForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    handleMakerPlanSubmit();
  });

  document.getElementById('btnGenerateMakerPlan')?.addEventListener('click', (e) => {
    e.preventDefault();
    handleMakerPlanSubmit();
  });
}

// ─── BUYER MODE: LIVE RESEARCH RUNNER & COMMENTARY STREAM ───
let commentaryInterval: any = null;
let currentChartEngine: 'dexscreener' | 'geckoterminal' | 'native' = 'dexscreener';
let currentDexInfoMode = false;
let currentActivePairAddress = '0xa43fe16908251ee70ef74718545e4fe6c5ccec9f';
let currentActiveChainId = 'ethereum';
let currentActiveTokenSymbol = 'PEPE';
let currentActiveTokenName = 'Pepe';
let currentActivePrice = 0.00000941;
let currentActiveChange = 3.82;
let currentActiveVolume = 14500000;
let activeNativeChart: TokenChartController | null = null;

export function switchDashboardChartEngine(engine: 'dexscreener' | 'geckoterminal' | 'native') {
  currentChartEngine = engine;

  // Update tabs active state
  document.querySelectorAll('.dex-engine-btn').forEach((btn) => {
    if (btn.getAttribute('data-engine') === engine) {
      btn.classList.add('is-active');
    } else {
      btn.classList.remove('is-active');
    }
  });

  document.querySelectorAll('.chart-big-option-card').forEach((btn) => {
    if (btn.getAttribute('data-engine') === engine) {
      btn.classList.add('is-active');
    } else {
      btn.classList.remove('is-active');
    }
  });

  const dexEmbed = document.getElementById('dashDexEmbed') as HTMLIFrameElement | null;
  const nativeHost = document.getElementById('dashNativeCanvasHost');
  const nativeSubbar = document.getElementById('dashNativeSubbar');
  const connBanner = document.getElementById('dashDexConnectionErrorBanner');

  if (connBanner) connBanner.style.display = 'none';

  if (engine === 'dexscreener') {
    if (dexEmbed) {
      dexEmbed.style.display = 'block';
      dexEmbed.src = `https://dexscreener.com/${currentActiveChainId}/${currentActivePairAddress}?embed=1&theme=dark&info=${currentDexInfoMode ? '1' : '0'}`;
    }
    if (nativeHost) nativeHost.style.display = 'none';
    if (nativeSubbar) nativeSubbar.style.display = 'none';
  } else if (engine === 'geckoterminal') {
    if (dexEmbed) {
      dexEmbed.style.display = 'block';
      const geckoChain = currentActiveChainId === 'ethereum' ? 'eth' : currentActiveChainId;
      dexEmbed.src = `https://www.geckoterminal.com/${geckoChain}/pools/${currentActivePairAddress}?embed=1&info=0&swaps=0&grayscale=0&light_chart=0`;
    }
    if (nativeHost) nativeHost.style.display = 'none';
    if (nativeSubbar) nativeSubbar.style.display = 'none';
  } else {
    // Native TradingView Canvas
    if (dexEmbed) dexEmbed.style.display = 'none';
    if (nativeHost) nativeHost.style.display = 'block';
    if (nativeSubbar) nativeSubbar.style.display = 'flex';
    mountNativeTradingViewChart();
  }
}

function mountNativeTradingViewChart() {
  const host = document.getElementById('dashNativeCanvasHost');
  if (!host) return;

  if (activeNativeChart) {
    activeNativeChart.destroy();
    activeNativeChart = null;
  }
  host.innerHTML = '';

  const hudOpen = document.getElementById('dashHudOpen');
  const hudHigh = document.getElementById('dashHudHigh');
  const hudLow = document.getElementById('dashHudLow');
  const hudClose = document.getElementById('dashHudClose');
  const hudVol = document.getElementById('dashHudVol');

  activeNativeChart = new TokenChartController({
    container: host,
    symbol: currentActiveTokenSymbol,
    name: currentActiveTokenName,
    currentPrice: currentActivePrice,
    change24h: currentActiveChange,
    volume24h: currentActiveVolume,
    onCrosshairMove: (data) => {
      if (data) {
        if (hudOpen) hudOpen.textContent = data.open ? formatPrice(data.open) : '-';
        if (hudHigh) hudHigh.textContent = data.high ? formatPrice(data.high) : '-';
        if (hudLow) hudLow.textContent = data.low ? formatPrice(data.low) : '-';
        if (hudClose) hudClose.textContent = formatPrice(data.close);
        if (hudVol) hudVol.textContent = data.volume ? formatUsd(data.volume) : '-';
      }
    },
  });
}

export async function startLiveCoinResearch(query: string, chainHint: string) {
  const cleanQ = query.trim();
  const statusBadge = document.getElementById('dashLiveReviewStatus');
  const streamBox = document.getElementById('dashCommentaryStream');
  const dexEmbed = document.getElementById('dashDexEmbed') as HTMLIFrameElement | null;
  const pairNameEl = document.getElementById('dashDexPairName');
  const pairChainEl = document.getElementById('dashDexPairChain');
  const priceEl = document.getElementById('dashDexPrice');
  const priceChgEl = document.getElementById('dashDexPriceChange');
  const directLinkEl = document.getElementById('dashDexDirectLink') as HTMLAnchorElement | null;
  const directRecoverEl = document.getElementById('btnRecoverDirect') as HTMLAnchorElement | null;
  const metricVolEl = document.getElementById('dashDexMetricVol');
  const metricLiqEl = document.getElementById('dashDexMetricLiq');
  const metricMcapEl = document.getElementById('dashDexMetricMcap');

  if (statusBadge) statusBadge.textContent = 'SCANNING ON-CHAIN BYTECODE...';
  if (commentaryInterval) clearInterval(commentaryInterval);

  // Clear or initialize commentary stream
  if (streamBox) {
    streamBox.innerHTML = `
      <div class="dash-commentary-line">
        <span class="dash-commentary-time">[00:01]</span>
        <span>Target: <strong style="color: #ffffff;">${cleanQ}</strong> on ${chainHint.toUpperCase()}</span>
      </div>
      <div class="dash-commentary-line">
        <span class="dash-commentary-time">[00:02]</span>
        <span class="dash-commentary-degen">"cooking"</span>
        <span>— Extracting on-chain liquidity depth and automated bytecodes...</span>
      </div>
      <div class="dash-commentary-line">
        <span class="dash-commentary-time">[00:03]</span>
        <span class="dash-commentary-degen">"cracking nuts"</span>
        <span>— Disassembling compiler metadata &amp; state modification hooks...</span>
      </div>
    `;
  }

  // 1. Resolve pair on DexScreener
  let resolvedPair: any = null;
  try {
    const dexRes = await searchDexPair(cleanQ);
    if (dexRes && dexRes.found && dexRes.pairAddress) {
      resolvedPair = dexRes;
      currentActivePairAddress = dexRes.pairAddress;
      currentActiveChainId = dexRes.chainId || chainHint;
      currentActiveTokenSymbol = dexRes.baseToken?.symbol || 'TOKEN';
      currentActiveTokenName = dexRes.baseToken?.name || currentActiveTokenSymbol;
      currentActivePrice = parseFloat(dexRes.priceUsd || '0.0001');
      currentActiveChange = dexRes.priceChange?.h24 ?? 3.82;
      currentActiveVolume = dexRes.volume?.h24 || 1000000;

      // Update embed URL according to active engine
      if (currentChartEngine === 'dexscreener' && dexEmbed) {
        dexEmbed.src = `https://dexscreener.com/${dexRes.chainId}/${dexRes.pairAddress}?embed=1&theme=dark&info=${currentDexInfoMode ? '1' : '0'}`;
      } else if (currentChartEngine === 'geckoterminal' && dexEmbed) {
        const geckoChain = dexRes.chainId === 'ethereum' ? 'eth' : dexRes.chainId;
        dexEmbed.src = `https://www.geckoterminal.com/${geckoChain}/pools/${dexRes.pairAddress}?embed=1&info=0&swaps=0&grayscale=0&light_chart=0`;
      } else if (currentChartEngine === 'native') {
        mountNativeTradingViewChart();
      }

      if (pairNameEl) pairNameEl.textContent = `${dexRes.baseToken?.symbol || 'TOKEN'} / ${dexRes.quoteToken?.symbol || 'USD'}`;
      if (pairChainEl) pairChainEl.textContent = (dexRes.chainId || chainHint).toUpperCase();
      if (priceEl && dexRes.priceUsd) priceEl.textContent = formatPrice(dexRes.priceUsd);
      
      // Update 24h Change Pill
      if (priceChgEl) {
        const chg = currentActiveChange;
        priceChgEl.textContent = `${chg >= 0 ? '+' : ''}${Number(chg).toFixed(2)}%`;
        priceChgEl.className = `dash-dex-change-tag ${chg >= 0 ? 'positive' : 'negative'}`;
      }

      // Update Quick Metrics Strip (Vol, Liq, MCap)
      if (metricVolEl && dexRes.volume?.h24) {
        metricVolEl.textContent = formatUsd(dexRes.volume.h24);
      }
      if (metricLiqEl && dexRes.liquidity?.usd) {
        metricLiqEl.textContent = formatUsd(dexRes.liquidity.usd);
      }
      if (metricMcapEl) {
        const mcap = dexRes.fdv || (dexRes.liquidity?.usd ? dexRes.liquidity.usd * 4 : 50000000);
        metricMcapEl.textContent = formatUsd(mcap);
      }

      if (directLinkEl && dexRes.url) directLinkEl.href = dexRes.url;
      if (directRecoverEl && dexRes.url) directRecoverEl.href = dexRes.url;

      // Highlight active trending chip if matched
      document.querySelectorAll('.dash-chip-btn[data-hot-symbol]').forEach((b) => {
        const sym = b.getAttribute('data-hot-symbol')?.toUpperCase();
        const baseSym = dexRes.baseToken?.symbol?.toUpperCase();
        if (sym && baseSym && sym === baseSym) {
          b.classList.add('is-active');
        } else {
          b.classList.remove('is-active');
        }
      });
    }
  } catch (err) {
    console.warn('DexScreener pair search fallback:', err);
  }

  // If query is an Ethereum address or pair wasn't resolved, use standard fallback
  if (!resolvedPair && cleanQ.startsWith('0x')) {
    currentActivePairAddress = cleanQ;
    currentActiveChainId = 'ethereum';
    currentActiveTokenSymbol = cleanQ.slice(0, 6);
    currentActiveTokenName = cleanQ;
    if (currentChartEngine === 'dexscreener' && dexEmbed) {
      dexEmbed.src = `https://dexscreener.com/ethereum/${cleanQ}?embed=1&theme=dark&info=${currentDexInfoMode ? '1' : '0'}`;
    } else if (currentChartEngine === 'native') {
      mountNativeTradingViewChart();
    }
    if (pairNameEl) pairNameEl.textContent = `${cleanQ.slice(0, 6)}...${cleanQ.slice(-4)}`;
  }

  // 2. Stream punchy degen commentary lines (as requested by user)
  const degenQuotes = [
    { text: '"hitting th nuts"', detail: 'Unpacking bytecode hashes & assembly opcodes...' },
    { text: '"time to text"', detail: 'Simulating buy order against Uniswap / Raydium router...' },
    { text: '"now we have to dick a hole"', detail: 'Deep audit: testing mint authority & transfer tax traps...' },
    { text: '"holy..."', detail: 'Clean execution verified: 0% buy tax / 0% sell tax!' },
  ];

  let quoteIdx = 0;
  commentaryInterval = setInterval(() => {
    if (quoteIdx < degenQuotes.length && streamBox) {
      const q = degenQuotes[quoteIdx];
      const line = document.createElement('div');
      line.className = 'dash-commentary-line';
      line.innerHTML = `
        <span class="dash-commentary-time">[00:0${quoteIdx + 4}]</span>
        <span class="dash-commentary-degen">${q.text}</span>
        <span>— ${q.detail}</span>
      `;
      streamBox.appendChild(line);
      streamBox.scrollTop = streamBox.scrollHeight;
      quoteIdx++;
    } else {
      clearInterval(commentaryInterval);
    }
  }, 700);

  // 3. Query Security API (GoPlus / Helius / RugCheck)
  const isSol = (!cleanQ.startsWith('0x') && cleanQ.length > 30) || chainHint === 'solana';
  const effectiveChain = isSol ? 'solana' : (chainHint === 'auto' ? 'ethereum' : chainHint);

  try {
    const report: SecurityScanResult = await scanTokenSecurity(cleanQ, effectiveChain);

    // Update Bar Graphs with real data
    renderBarGraphs(report);

    // Update Status Badge
    if (statusBadge) {
      statusBadge.textContent = report.verdict === 'SAFE' ? 'AUDIT VERIFIED: CLEAN' : `AUDIT WARNING: ${report.verdict}`;
    }

    // Call Gemini AI Audit
    const aiAudit = await requestAiSecurityAudit({
      tokenSymbol: resolvedPair?.baseToken?.symbol || (cleanQ.startsWith('0x') ? cleanQ.slice(0, 5) : cleanQ),
      tokenName: resolvedPair?.baseToken?.name || 'Meme Coin',
      chain: effectiveChain,
      address: cleanQ,
      riskScore: report.score,
      buyTax: report.buyTax,
      sellTax: report.sellTax,
      isHoneypot: report.isHoneypot,
      mintRevoked: report.mintAuthorityRevoked,
      freezeRevoked: report.freezeAuthorityRevoked,
    });

    if (aiAudit) {
      renderAiAuditCard(aiAudit, report.score);
    }
  } catch (err) {
    console.error('Security scan failed:', err);
  }
}

// ─── RENDER VISUAL BAR GRAPHS ───
function renderBarGraphs(report: SecurityScanResult) {
  // Graph 1: Honeypot & Tax Meter
  const graphHoneypotStatus = document.getElementById('graphHoneypotStatus');
  const lblBuyTaxVal = document.getElementById('lblBuyTaxVal');
  const barBuyTax = document.getElementById('barBuyTax');
  const lblSellTaxVal = document.getElementById('lblSellTaxVal');
  const barSellTax = document.getElementById('barSellTax');
  const lblCanSell = document.getElementById('lblCanSell');
  const lblBlacklist = document.getElementById('lblBlacklist');

  const buyTax = Math.min(Math.max(report.buyTax, 0), 100);
  const sellTax = Math.min(Math.max(report.sellTax, 0), 100);

  if (lblBuyTaxVal) lblBuyTaxVal.textContent = `${buyTax.toFixed(1)}%`;
  if (barBuyTax) {
    barBuyTax.style.width = `${Math.max(buyTax, 2)}%`;
    barBuyTax.className = `dash-bar-fill ${buyTax > 15 ? 'fill-red' : buyTax > 5 ? 'fill-yellow' : 'fill-green'}`;
  }

  if (lblSellTaxVal) lblSellTaxVal.textContent = `${sellTax.toFixed(1)}%`;
  if (barSellTax) {
    barSellTax.style.width = `${Math.max(sellTax, 2)}%`;
    barSellTax.className = `dash-bar-fill ${sellTax > 15 ? 'fill-red' : sellTax > 5 ? 'fill-yellow' : 'fill-green'}`;
  }

  if (lblCanSell) {
    lblCanSell.textContent = report.cannotSell ? 'NO (CANNOT SELL - HONEYPOT)' : 'YES (No Limits)';
    lblCanSell.style.color = report.cannotSell ? '#ef4444' : '#10b981';
  }

  if (lblBlacklist) {
    lblBlacklist.textContent = report.isHoneypot ? 'MALICIOUS HOOKS DETECTED' : 'NONE DETECTED';
    lblBlacklist.style.color = report.isHoneypot ? '#ef4444' : '#10b981';
  }

  if (graphHoneypotStatus) {
    if (report.isHoneypot) {
      graphHoneypotStatus.textContent = 'HONEYPOT DETECTED';
      graphHoneypotStatus.className = 'dash-graph-status danger';
    } else if (buyTax > 5 || sellTax > 5) {
      graphHoneypotStatus.textContent = `TAX WARNING (${buyTax}% / ${sellTax}%)`;
      graphHoneypotStatus.className = 'dash-graph-status warning';
    } else {
      graphHoneypotStatus.textContent = '0% TAX · CLEAN';
      graphHoneypotStatus.className = 'dash-graph-status safe';
    }
  }

  // Graph 2: RugCheck Liquidity Health
  const graphLpStatus = document.getElementById('graphLpStatus');
  const lblLpScore = document.getElementById('lblLpScore');
  const segLocked = document.getElementById('segLpLocked');
  const segBurned = document.getElementById('segLpBurned');
  const segUnlocked = document.getElementById('segLpUnlocked');
  const lblLockedPct = document.getElementById('lblLpLockedPct');
  const lblBurnedPct = document.getElementById('lblLpBurnedPct');
  const lblUnlockedPct = document.getElementById('lblLpUnlockedPct');

  const lockedPct = Math.round(report.lpLockedPercent || 90);
  const burnedPct = lockedPct > 90 ? 10 : 0;
  const unlockedPct = Math.max(0, 100 - lockedPct - burnedPct);

  if (segLocked) segLocked.style.width = `${lockedPct}%`;
  if (segBurned) segBurned.style.width = `${burnedPct}%`;
  if (segUnlocked) segUnlocked.style.width = `${unlockedPct}%`;

  if (lblLockedPct) lblLockedPct.textContent = `${lockedPct}%`;
  if (lblBurnedPct) lblBurnedPct.textContent = `${burnedPct}%`;
  if (lblUnlockedPct) lblUnlockedPct.textContent = `${unlockedPct}%`;

  if (lblLpScore) lblLpScore.textContent = `${lockedPct + burnedPct}% Protected`;
  if (graphLpStatus) {
    if (unlockedPct > 30) {
      graphLpStatus.textContent = 'HIGH UNLOCKED LP RISK';
      graphLpStatus.className = 'dash-graph-status danger';
    } else if (unlockedPct > 10) {
      graphLpStatus.textContent = 'PARTIAL LP LOCK';
      graphLpStatus.className = 'dash-graph-status warning';
    } else {
      graphLpStatus.textContent = '100% SECURED';
      graphLpStatus.className = 'dash-graph-status safe';
    }
  }

  // Graph 3: Rug Pull Check / Authority Status
  const graphAuthStatus = document.getElementById('graphAuthStatus');
  const lblMintAuth = document.getElementById('lblMintAuth');
  const barMintAuth = document.getElementById('barMintAuth');
  const lblFreezeAuth = document.getElementById('lblFreezeAuth');
  const barFreezeAuth = document.getElementById('barFreezeAuth');
  const lblOwnership = document.getElementById('lblOwnership');

  if (lblMintAuth) {
    lblMintAuth.textContent = report.mintAuthorityRevoked ? 'Revoked (No Inflation)' : 'Active (Dev Can Mint Supply)';
    lblMintAuth.style.color = report.mintAuthorityRevoked ? '#10b981' : '#ef4444';
  }
  if (barMintAuth) {
    barMintAuth.style.width = report.mintAuthorityRevoked ? '100%' : '15%';
    barMintAuth.className = `dash-bar-fill ${report.mintAuthorityRevoked ? 'fill-green' : 'fill-red'}`;
  }

  if (lblFreezeAuth) {
    lblFreezeAuth.textContent = report.freezeAuthorityRevoked ? 'Revoked (Cannot Freeze)' : 'Active (Dev Can Freeze Wallets)';
    lblFreezeAuth.style.color = report.freezeAuthorityRevoked ? '#10b981' : '#ef4444';
  }
  if (barFreezeAuth) {
    barFreezeAuth.style.width = report.freezeAuthorityRevoked ? '100%' : '15%';
    barFreezeAuth.className = `dash-bar-fill ${report.freezeAuthorityRevoked ? 'fill-green' : 'fill-red'}`;
  }

  if (lblOwnership) {
    lblOwnership.textContent = report.ownershipRenounced ? 'Renounced to Zero Address' : 'Active Owner Key';
    lblOwnership.style.color = report.ownershipRenounced ? '#10b981' : '#f59e0b';
  }

  if (graphAuthStatus) {
    if (report.mintAuthorityRevoked && report.freezeAuthorityRevoked) {
      graphAuthStatus.textContent = 'RENOUNCED / IMMUTABLE';
      graphAuthStatus.className = 'dash-graph-status safe';
    } else {
      graphAuthStatus.textContent = 'UNREVOKED AUTHORITY';
      graphAuthStatus.className = 'dash-graph-status danger';
    }
  }

  // Graph 4: Whale & Holder Concentration
  const graphWhaleStatus = document.getElementById('graphWhaleStatus');
  const lblTop10Share = document.getElementById('lblTop10Share');
  const barTop10Share = document.getElementById('barTop10Share');
  const lblMaxWallet = document.getElementById('lblMaxWallet');
  const barMaxWallet = document.getElementById('barMaxWallet');

  const top10 = report.top10HoldersShare || 18.4;
  const maxSingle = Math.min(top10 * 0.22, 12).toFixed(1);

  if (lblTop10Share) lblTop10Share.textContent = `${top10.toFixed(1)}%`;
  if (barTop10Share) {
    barTop10Share.style.width = `${Math.min(top10, 100)}%`;
    barTop10Share.className = `dash-bar-fill ${top10 > 40 ? 'fill-red' : top10 > 25 ? 'fill-yellow' : 'fill-green'}`;
  }

  if (lblMaxWallet) lblMaxWallet.textContent = `${maxSingle}%`;
  if (barMaxWallet) {
    barMaxWallet.style.width = `${Math.min(Number(maxSingle) * 6, 100)}%`;
  }

  if (graphWhaleStatus) {
    if (top10 > 50) {
      graphWhaleStatus.textContent = 'HIGH CONCENTRATION RISK';
      graphWhaleStatus.className = 'dash-graph-status danger';
    } else if (top10 > 25) {
      graphWhaleStatus.textContent = 'MODERATE SPREAD';
      graphWhaleStatus.className = 'dash-graph-status warning';
    } else {
      graphWhaleStatus.textContent = 'DECENTRALIZED';
      graphWhaleStatus.className = 'dash-graph-status safe';
    }
  }
}

// ─── RENDER GEMINI AI AUDITOR CARD ───
function renderAiAuditCard(audit: any, score: number) {
  const badge = document.getElementById('dashAiRiskBadge');
  const summary = document.getElementById('dashAiSummaryText');
  const strengthsList = document.getElementById('dashAiStrengthsList');
  const recList = document.getElementById('dashAiRecList');

  if (badge) {
    badge.textContent = `RISK: ${audit.riskLevel || 'LOW'} (${score}/100)`;
    if (audit.riskLevel === 'CRITICAL' || audit.riskLevel === 'HIGH') {
      badge.style.color = '#ef4444';
      badge.style.borderColor = 'rgba(239, 68, 68, 0.4)';
    } else if (audit.riskLevel === 'MEDIUM') {
      badge.style.color = '#f59e0b';
      badge.style.borderColor = 'rgba(245, 158, 11, 0.4)';
    } else {
      badge.style.color = '#10b981';
      badge.style.borderColor = 'rgba(16, 185, 129, 0.4)';
    }
  }

  if (summary && audit.summary) {
    summary.textContent = audit.summary;
  }

  if (strengthsList && Array.isArray(audit.keyStrengths)) {
    strengthsList.innerHTML = audit.keyStrengths.map((s: string) => `<li>✓ ${s}</li>`).join('');
  }

  if (recList) {
    if (audit.recommendation) {
      recList.innerHTML = `<li>• ${audit.recommendation}</li>`;
    }
  }
}

// ─── MAKER MODE: GEMINI AI LAUNCH PLAN GENERATOR ───
async function handleMakerPlanSubmit() {
  const nameInput = document.getElementById('makerCoinName') as HTMLInputElement | null;
  const symbolInput = document.getElementById('makerCoinSymbol') as HTMLInputElement | null;
  const chainSelect = document.getElementById('makerChain') as HTMLSelectElement | null;
  const targetLiqInput = document.getElementById('makerTargetLiquidity') as HTMLInputElement | null;
  const conceptInput = document.getElementById('makerConcept') as HTMLTextAreaElement | null;
  const btnSubmit = document.getElementById('btnGenerateMakerPlan') as HTMLButtonElement | null;
  const outputContainer = document.getElementById('dashMakerPlanOutput');

  const coinName = nameInput?.value.trim() || 'Dog Wif Neon Glasses';
  const symbol = symbolInput?.value.trim() || 'DWNG';
  const chain = chainSelect?.value || 'Solana';
  const targetLiquidity = targetLiqInput?.value.trim() || '$10,000 SOL Pool';
  const concept = conceptInput?.value.trim() || 'Community meme coin with high-frequency alpha access.';

  if (btnSubmit) {
    btnSubmit.disabled = true;
    btnSubmit.innerHTML = `<span>🤖 Generating Master Plan with Gemini 2.5 Flash...</span>`;
  }

  try {
    const plan: MakerPlanResponse | null = await generateMakerLaunchPlan({
      coinName,
      symbol,
      concept,
      chain,
      targetLiquidity,
    });

    if (outputContainer) outputContainer.style.display = 'flex';

    if (plan) {
      // 1. Title & Overview
      const titleEl = document.getElementById('planOutputTitle');
      const overviewEl = document.getElementById('planOutputOverview');
      if (titleEl) titleEl.textContent = `Master Launch & Security Playbook for ${coinName} ($${symbol})`;
      if (overviewEl) overviewEl.textContent = plan.overview || 'Architected by LedgerGuard Autonomous Launch AI.';

      // 2. Phases Roadmap
      const phasesContainer = document.getElementById('planPhasesContainer');
      if (phasesContainer && Array.isArray(plan.phases)) {
        phasesContainer.innerHTML = plan.phases
          .map(
            (p) => `
            <div class="dash-plan-phase-card">
              <div class="dash-plan-phase-title">
                <span class="p-badge">PHASE ${p.phaseNumber}</span>
                <span>${p.phaseTitle}</span>
              </div>
              <ul class="dash-plan-steps-list">
                ${p.steps.map((step) => `<li class="dash-plan-step-item"><span class="dash-plan-step-check">✓</span><span>${step}</span></li>`).join('')}
              </ul>
              ${
                p.recommendedTools?.length
                  ? `<div style="font-size: 11.5px; color: #94a3b8; font-weight: 700;">Tools: ${p.recommendedTools.join(' · ')}</div>`
                  : ''
              }
            </div>
          `
          )
          .join('');
      }

      // 3. Security Checklist
      const checklistEl = document.getElementById('planSecurityChecklist');
      if (checklistEl && Array.isArray(plan.securityChecklist)) {
        checklistEl.innerHTML = plan.securityChecklist
          .map((item) => `<li class="dash-plan-step-item"><span class="dash-plan-step-check">🛡️</span><span>${item}</span></li>`)
          .join('');
      }

      // 4. Verified Resource Links Grid
      const resourcesGrid = document.getElementById('planResourcesGrid');
      if (resourcesGrid && Array.isArray(plan.verifiedResourceLinks)) {
        resourcesGrid.innerHTML = plan.verifiedResourceLinks
          .map(
            (r) => `
            <a href="${r.url}" target="_blank" rel="noopener noreferrer" class="dash-resource-card">
              <div class="dash-resource-top">
                <span class="dash-resource-name">${r.name} ↗</span>
                <span class="dash-resource-cat">${r.category}</span>
              </div>
              <p class="dash-resource-purpose">${r.purpose}</p>
            </a>
          `
          )
          .join('');
      }

      // Scroll into view
      outputContainer?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  } catch (err) {
    console.error('Failed to generate launch plan:', err);
  } finally {
    if (btnSubmit) {
      btnSubmit.disabled = false;
      btnSubmit.innerHTML = `
        <svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M8 0L9.5 5.5L15 7L9.5 8.5L8 14L6.5 8.5L1 7L6.5 5.5L8 0Z"/></svg>
        <span>Generate AI Master Launch Plan</span>
      `;
    }
  }
}



