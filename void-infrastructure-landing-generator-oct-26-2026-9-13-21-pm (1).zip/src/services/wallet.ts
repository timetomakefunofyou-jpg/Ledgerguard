// Multi-chain Real Web3 Wallet Service supporting EVM (Ethereum, Base, BSC) and Solana (Phantom, Solflare)

export type ChainType = 'evm' | 'solana';

export interface WalletState {
  isConnected: boolean;
  chainType: ChainType | null;
  chainId: string | number | null;
  chainName: string;
  address: string | null;
  shortAddress: string | null;
  balance: string | null;
  balanceSymbol: string;
  walletName: string;
}

type WalletListener = (state: WalletState) => void;

const KNOWN_EVM_CHAINS: Record<string, { name: string; symbol: string; rpcUrl?: string }> = {
  '0x1': { name: 'Ethereum', symbol: 'ETH' },
  '1': { name: 'Ethereum', symbol: 'ETH' },
  '0x2105': { name: 'Base', symbol: 'ETH' },
  '8453': { name: 'Base', symbol: 'ETH' },
  '0x38': { name: 'BNB Chain', symbol: 'BNB' },
  '56': { name: 'BNB Chain', symbol: 'BNB' },
  '0xa4b1': { name: 'Arbitrum One', symbol: 'ETH' },
  '42161': { name: 'Arbitrum One', symbol: 'ETH' },
  '0x89': { name: 'Polygon', symbol: 'POL' },
  '137': { name: 'Polygon', symbol: 'POL' },
};

class WalletService {
  private state: WalletState = {
    isConnected: false,
    chainType: null,
    chainId: null,
    chainName: '',
    address: null,
    shortAddress: null,
    balance: null,
    balanceSymbol: '',
    walletName: '',
  };

  private listeners: Set<WalletListener> = new Set();

  constructor() {
    this.initEventListeners();
    // Auto restore if previously connected
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('lg_wallet_chain');
      if (saved === 'evm' && this.hasEthereum()) {
        this.reconnectEvm().catch(() => {});
      } else if (saved === 'solana' && this.hasSolana()) {
        this.reconnectSolana().catch(() => {});
      }
    }
  }

  public getState(): WalletState {
    return { ...this.state };
  }

  public subscribe(fn: WalletListener): () => void {
    this.listeners.add(fn);
    fn(this.getState());
    return () => this.listeners.delete(fn);
  }

  private notify() {
    const s = this.getState();
    this.listeners.forEach((fn) => fn(s));
  }

  public hasEthereum(): boolean {
    return typeof window !== 'undefined' && Boolean((window as any).ethereum);
  }

  public hasSolana(): boolean {
    return typeof window !== 'undefined' && Boolean((window as any).solana);
  }

  public getAvailableWallets() {
    const w = typeof window !== 'undefined' ? (window as any) : {};
    return {
      hasMetaMask: Boolean(w.ethereum?.isMetaMask),
      hasCoinbase: Boolean(w.ethereum?.isCoinbaseWallet),
      hasRabby: Boolean(w.ethereum?.isRabby),
      hasGenericEvm: Boolean(w.ethereum),
      hasPhantom: Boolean(w.solana?.isPhantom),
      hasSolflare: Boolean(w.solflare?.isSolflare || (w.solana && !w.solana.isPhantom)),
    };
  }

  // ─── EVM CONNECT ───
  public async connectEvm(targetChainHex = '0x2105'): Promise<WalletState> {
    if (!this.hasEthereum()) {
      throw new Error('No EVM wallet detected (MetaMask, Coinbase, or Rabby required). Please install a browser extension.');
    }
    const eth = (window as any).ethereum;

    // Request accounts
    const accounts: string[] = await eth.request({ method: 'eth_requestAccounts' });
    if (!accounts || accounts.length === 0) {
      throw new Error('User rejected the connection request.');
    }

    const address = accounts[0];
    const chainIdHex: string = await eth.request({ method: 'eth_chainId' });

    // Identify wallet
    let walletName = 'EVM Wallet';
    if (eth.isRabby) walletName = 'Rabby';
    else if (eth.isCoinbaseWallet) walletName = 'Coinbase';
    else if (eth.isMetaMask) walletName = 'MetaMask';

    const chainInfo = KNOWN_EVM_CHAINS[chainIdHex] || { name: 'EVM Chain', symbol: 'ETH' };
    const balance = await this.fetchEvmBalance(address);

    this.state = {
      isConnected: true,
      chainType: 'evm',
      chainId: chainIdHex,
      chainName: chainInfo.name,
      address,
      shortAddress: this.shorten(address),
      balance,
      balanceSymbol: chainInfo.symbol,
      walletName,
    };

    localStorage.setItem('lg_wallet_chain', 'evm');
    this.notify();
    return this.getState();
  }

  private async reconnectEvm(): Promise<void> {
    const eth = (window as any).ethereum;
    if (!eth) return;
    const accounts: string[] = await eth.request({ method: 'eth_accounts' });
    if (accounts && accounts.length > 0) {
      await this.connectEvm();
    }
  }

  public async switchEvmChain(chainIdHex: string): Promise<void> {
    const eth = (window as any).ethereum;
    if (!eth) throw new Error('EVM provider not found');
    try {
      await eth.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: chainIdHex }],
      });
    } catch (switchError: any) {
      // 4902 code indicates the chain has not been added
      if (switchError.code === 4902 && chainIdHex === '0x2105') {
        await eth.request({
          method: 'wallet_addEthereumChain',
          params: [
            {
              chainId: '0x2105',
              chainName: 'Base',
              nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
              rpcUrls: ['https://mainnet.base.org'],
              blockExplorerUrls: ['https://basescan.org'],
            },
          ],
        });
      } else {
        throw switchError;
      }
    }
  }

  private async fetchEvmBalance(address: string): Promise<string> {
    try {
      const eth = (window as any).ethereum;
      const rawHex: string = await eth.request({
        method: 'eth_getBalance',
        params: [address, 'latest'],
      });
      const wei = BigInt(rawHex);
      // Format 4 decimal places
      const ethVal = Number(wei) / 1e18;
      return ethVal >= 0.0001 ? ethVal.toFixed(4) : ethVal === 0 ? '0.0000' : '<0.0001';
    } catch {
      return '0.00';
    }
  }

  // ─── SOLANA CONNECT ───
  public async connectSolana(): Promise<WalletState> {
    if (!this.hasSolana()) {
      throw new Error('No Solana wallet detected. Please install Phantom or Solflare.');
    }
    const sol = (window as any).solana;

    const resp = await sol.connect();
    const address = resp.publicKey ? resp.publicKey.toString() : sol.publicKey.toString();

    let walletName = 'Solana Wallet';
    if (sol.isPhantom) walletName = 'Phantom';
    else if ((window as any).solflare?.isSolflare) walletName = 'Solflare';

    const balance = await this.fetchSolBalance(address);

    this.state = {
      isConnected: true,
      chainType: 'solana',
      chainId: 'solana-mainnet',
      chainName: 'Solana',
      address,
      shortAddress: this.shorten(address),
      balance,
      balanceSymbol: 'SOL',
      walletName,
    };

    localStorage.setItem('lg_wallet_chain', 'solana');
    this.notify();
    return this.getState();
  }

  private async reconnectSolana(): Promise<void> {
    const sol = (window as any).solana;
    if (!sol || !sol.isPhantom) return;
    try {
      const resp = await sol.connect({ onlyIfTrusted: true });
      if (resp && resp.publicKey) {
        await this.connectSolana();
      }
    } catch {}
  }

  private async fetchSolBalance(address: string): Promise<string> {
    try {
      const res = await fetch('https://api.mainnet-beta.solana.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'getBalance',
          params: [address],
        }),
      });
      const data = await res.json();
      if (data?.result?.value !== undefined) {
        const lamports = Number(data.result.value);
        const solVal = lamports / 1e9;
        return solVal >= 0.001 ? solVal.toFixed(3) : solVal === 0 ? '0.00' : '<0.001';
      }
      return '0.00';
    } catch {
      return '0.00';
    }
  }

  // ─── DISCONNECT ───
  public async disconnect(): Promise<void> {
    if (this.state.chainType === 'solana' && (window as any).solana?.disconnect) {
      try {
        await (window as any).solana.disconnect();
      } catch {}
    }
    localStorage.removeItem('lg_wallet_chain');
    this.state = {
      isConnected: false,
      chainType: null,
      chainId: null,
      chainName: '',
      address: null,
      shortAddress: null,
      balance: null,
      balanceSymbol: '',
      walletName: '',
    };
    this.notify();
  }

  private initEventListeners() {
    if (typeof window === 'undefined') return;

    // EVM listeners
    const eth = (window as any).ethereum;
    if (eth && eth.on) {
      eth.on('accountsChanged', (accounts: string[]) => {
        if (!accounts || accounts.length === 0) {
          this.disconnect();
        } else if (this.state.chainType === 'evm') {
          this.connectEvm().catch(() => {});
        }
      });
      eth.on('chainChanged', () => {
        if (this.state.chainType === 'evm') {
          this.connectEvm().catch(() => {});
        }
      });
    }

    // Solana listeners
    const sol = (window as any).solana;
    if (sol && sol.on) {
      sol.on('disconnect', () => {
        if (this.state.chainType === 'solana') {
          this.disconnect();
        }
      });
      sol.on('accountChanged', () => {
        if (this.state.chainType === 'solana') {
          this.connectSolana().catch(() => {});
        }
      });
    }
  }

  private shorten(addr: string): string {
    if (!addr) return '';
    if (addr.length <= 10) return addr;
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  }
}

export const walletService = new WalletService();
