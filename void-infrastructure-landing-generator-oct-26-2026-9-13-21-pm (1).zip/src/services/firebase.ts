import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  setDoc,
  deleteDoc,
  collection,
  onSnapshot,
  getDocFromServer,
  query,
  orderBy,
  limit
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Test Firestore Connection as required by Firebase Integration Skill
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase warning: Client is offline or disconnected.');
    }
    return false;
  }
}
testConnection();

// Strict Error Handling Types and Handler
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ─── AUTHENTICATION HELPERS ───
const googleProvider = new GoogleAuthProvider();

export async function loginWithGoogle(): Promise<User> {
  try {
    const cred = await signInWithPopup(auth, googleProvider);
    // Sync basic profile document
    if (cred.user) {
      await saveUserProfile(cred.user);
    }
    return cred.user;
  } catch (error: any) {
    console.error('Google Sign In Error:', error);
    throw error;
  }
}

export async function loginWithEmail(email: string, pass: string): Promise<User> {
  const cred = await signInWithEmailAndPassword(auth, email, pass);
  return cred.user;
}

export async function registerWithEmail(email: string, pass: string): Promise<User> {
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  if (cred.user) {
    await saveUserProfile(cred.user);
  }
  return cred.user;
}

export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

export async function saveUserProfile(user: User): Promise<void> {
  const path = `users/${user.uid}`;
  try {
    await setDoc(doc(db, 'users', user.uid), {
      id: user.uid,
      email: user.email || '',
      displayName: user.displayName || user.email?.split('@')[0] || 'Trader',
      photoURL: user.photoURL || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

// ─── WATCHLIST PERSISTENCE ───
export interface WatchlistToken {
  id: string;
  userId: string;
  pairAddress: string;
  chainId: string;
  baseTokenSymbol: string;
  baseTokenName?: string;
  priceUsd?: string;
  liquidityUsd?: number;
  riskScore?: number;
  isHoneypot?: boolean;
  addedAt: string;
}

export async function addToWatchlist(userId: string, item: Omit<WatchlistToken, 'id' | 'userId' | 'addedAt'>): Promise<string> {
  const safeId = `${item.chainId}_${item.pairAddress.replace(/[^a-zA-Z0-9]/g, '').slice(0, 48)}`;
  const path = `users/${userId}/watchlist/${safeId}`;
  const payload: WatchlistToken = {
    ...item,
    id: safeId,
    userId,
    addedAt: new Date().toISOString(),
  };
  try {
    await setDoc(doc(db, 'users', userId, 'watchlist', safeId), payload);
    return safeId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function removeFromWatchlist(userId: string, watchId: string): Promise<void> {
  const path = `users/${userId}/watchlist/${watchId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'watchlist', safeIdOrFallback(watchId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

function safeIdOrFallback(id: string): string {
  return id.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 128);
}

export function subscribeUserWatchlist(userId: string, onUpdate: (items: WatchlistToken[]) => void): () => void {
  const path = `users/${userId}/watchlist`;
  return onSnapshot(collection(db, 'users', userId, 'watchlist'), (snap) => {
    const list: WatchlistToken[] = [];
    snap.forEach((docSnap) => {
      list.push(docSnap.data() as WatchlistToken);
    });
    // Sort recently added first
    list.sort((a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime());
    onUpdate(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, path);
  });
}

// ─── AUDIT LOG PERSISTENCE ───
export interface AuditRecord {
  id: string;
  userId: string;
  contractAddress: string;
  chainId: string;
  tokenName?: string;
  tokenSymbol: string;
  riskScore?: number;
  honeypotStatus?: string;
  liquidityScore?: number;
  auditedAt: string;
}

export async function recordAuditLog(userId: string, log: Omit<AuditRecord, 'id' | 'userId' | 'auditedAt'>): Promise<string> {
  const safeId = `audit_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const path = `users/${userId}/auditLogs/${safeId}`;
  const payload: AuditRecord = {
    ...log,
    id: safeId,
    userId,
    auditedAt: new Date().toISOString(),
  };
  try {
    await setDoc(doc(db, 'users', userId, 'auditLogs', safeId), payload);
    return safeId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export function subscribeUserAuditLogs(userId: string, onUpdate: (logs: AuditRecord[]) => void): () => void {
  const path = `users/${userId}/auditLogs`;
  return onSnapshot(
    query(collection(db, 'users', userId, 'auditLogs'), orderBy('auditedAt', 'desc'), limit(15)),
    (snap) => {
      const logs: AuditRecord[] = [];
      snap.forEach((docSnap) => {
        logs.push(docSnap.data() as AuditRecord);
      });
      onUpdate(logs);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}
