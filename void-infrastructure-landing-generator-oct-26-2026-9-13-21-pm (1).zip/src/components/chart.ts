import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickSeries,
  AreaSeries,
  HistogramSeries,
  ColorType,
  Time,
  CandlestickData,
  AreaData,
  HistogramData,
} from 'lightweight-charts';

export type ChartMode = 'candles' | 'area';
export type Timeframe = '15m' | '1h' | '4h' | '1D';

export interface TokenChartParams {
  container: HTMLElement;
  symbol: string;
  name: string;
  currentPrice: number;
  change24h: number;
  volume24h: number;
  onCrosshairMove?: (data: {
    time: string;
    open?: number;
    high?: number;
    low?: number;
    close: number;
    volume?: number;
    changePercent?: number;
  } | null) => void;
}

export class TokenChartController {
  private chart: IChartApi;
  private candleSeries: ISeriesApi<'Candlestick'> | null = null;
  private areaSeries: ISeriesApi<'Area'> | null = null;
  private volumeSeries: ISeriesApi<'Histogram'>;

  private currentMode: ChartMode = 'candles';
  private currentTimeframe: Timeframe = '15m';

  private symbol: string;
  private currentPrice: number;
  private change24h: number;
  private volume24h: number;
  private onCrosshairMoveCallback?: (data: any) => void;

  private liveTickInterval: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  // Cached generated series data per timeframe
  private cache: Map<Timeframe, { candles: CandlestickData<Time>[]; volume: HistogramData<Time>[] }> = new Map();

  constructor(params: TokenChartParams) {
    this.symbol = params.symbol;
    this.currentPrice = params.currentPrice > 0 ? params.currentPrice : 0.0001;
    this.change24h = params.change24h;
    this.volume24h = params.volume24h > 0 ? params.volume24h : 500000;
    this.onCrosshairMoveCallback = params.onCrosshairMove;

    // Create TradingView Lightweight Chart
    this.chart = createChart(params.container, {
      layout: {
        background: { type: ColorType.Solid, color: '#07080b' },
        textColor: '#cbd5e1',
        fontSize: 12,
        fontFamily: "'Space Grotesk', -apple-system, system-ui, sans-serif",
      },
      grid: {
        vertLines: { color: 'rgba(255, 255, 255, 0.04)' },
        horzLines: { color: 'rgba(255, 255, 255, 0.04)' },
      },
      crosshair: {
        mode: 1, // Magnet
        vertLine: {
          color: 'rgba(255, 255, 255, 0.3)',
          width: 1,
          style: 3, // Dashed
          labelBackgroundColor: '#1e2430',
        },
        horzLine: {
          color: 'rgba(255, 255, 255, 0.3)',
          width: 1,
          style: 3,
          labelBackgroundColor: '#1e2430',
        },
      },
      rightPriceScale: {
        borderColor: 'rgba(255, 255, 255, 0.1)',
        scaleMargins: {
          top: 0.1,
          bottom: 0.22, // Reserve lower area for volume bars
        },
      },
      timeScale: {
        borderColor: 'rgba(255, 255, 255, 0.1)',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: false,
      },
      handleScale: {
        axisPressedMouseMove: true,
        mouseWheel: true,
        pinch: true,
      },
    });

    // Add Volume histogram series
    this.volumeSeries = this.chart.addSeries(HistogramSeries, {
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: '', // Separate price scale overlay
    });
    this.volumeSeries.priceScale().applyOptions({
      scaleMargins: {
        top: 0.8,
        bottom: 0,
      },
    });

    // Initialize Default Candlestick Series
    this.renderActiveSeries();

    // Setup Crosshair tooltip listener
    this.setupCrosshair();

    // Responsive container auto-resize
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver((entries) => {
        if (!entries || entries.length === 0) return;
        const { width, height } = entries[0].contentRect;
        if (width > 0 && height > 0) {
          this.chart.applyOptions({ width, height });
        }
      });
      this.resizeObserver.observe(params.container);
    }

    // Start subtle realistic live price ticks
    this.startLiveTicks();
  }

  public setMode(mode: ChartMode) {
    if (this.currentMode === mode) return;
    this.currentMode = mode;
    this.renderActiveSeries();
  }

  public setTimeframe(tf: Timeframe) {
    if (this.currentTimeframe === tf) return;
    this.currentTimeframe = tf;
    this.renderActiveSeries();
  }

  public getMode(): ChartMode {
    return this.currentMode;
  }

  public getTimeframe(): Timeframe {
    return this.currentTimeframe;
  }

  private renderActiveSeries() {
    const data = this.getOrGenerateData(this.currentTimeframe);

    // Remove existing main series
    if (this.candleSeries) {
      this.chart.removeSeries(this.candleSeries);
      this.candleSeries = null;
    }
    if (this.areaSeries) {
      this.chart.removeSeries(this.areaSeries);
      this.areaSeries = null;
    }

    if (this.currentMode === 'candles') {
      this.candleSeries = this.chart.addSeries(CandlestickSeries, {
        upColor: '#10b981',
        downColor: '#ef4444',
        borderVisible: false,
        wickUpColor: '#10b981',
        wickDownColor: '#ef4444',
      });
      this.candleSeries.setData(data.candles);
    } else {
      const areaData: AreaData<Time>[] = data.candles.map((c) => ({
        time: c.time,
        value: c.close,
      }));
      this.areaSeries = this.chart.addSeries(AreaSeries, {
        topColor: 'rgba(16, 185, 129, 0.45)',
        bottomColor: 'rgba(16, 185, 129, 0.01)',
        lineColor: '#10b981',
        lineWidth: 2,
      });
      this.areaSeries.setData(areaData);
    }

    this.volumeSeries.setData(data.volume);
    this.chart.timeScale().fitContent();
  }

  private setupCrosshair() {
    this.chart.subscribeCrosshairMove((param) => {
      if (!this.onCrosshairMoveCallback) return;

      if (
        !param.point ||
        !param.time ||
        param.point.x < 0 ||
        param.point.y < 0
      ) {
        this.onCrosshairMoveCallback(null);
        return;
      }

      let close = this.currentPrice;
      let open: number | undefined;
      let high: number | undefined;
      let low: number | undefined;

      if (this.candleSeries && param.seriesData.get(this.candleSeries)) {
        const cData = param.seriesData.get(this.candleSeries) as any;
        open = cData.open;
        high = cData.high;
        low = cData.low;
        close = cData.close;
      } else if (this.areaSeries && param.seriesData.get(this.areaSeries)) {
        const aData = param.seriesData.get(this.areaSeries) as any;
        close = aData.value;
      }

      let volumeVal: number | undefined;
      if (param.seriesData.get(this.volumeSeries)) {
        const vData = param.seriesData.get(this.volumeSeries) as any;
        volumeVal = vData.value;
      }

      const changePct = open && open > 0 ? ((close - open) / open) * 100 : undefined;

      this.onCrosshairMoveCallback({
        time: String(param.time),
        open,
        high,
        low,
        close,
        volume: volumeVal,
        changePercent: changePct,
      });
    });
  }

  private startLiveTicks() {
    if (this.liveTickInterval) clearInterval(this.liveTickInterval);

    this.liveTickInterval = window.setInterval(() => {
      const data = this.cache.get(this.currentTimeframe);
      if (!data || data.candles.length === 0) return;

      const lastCandle = data.candles[data.candles.length - 1];
      const deltaPercent = (Math.random() - 0.49) * 0.008; // +/- 0.4%
      const newClose = Math.max(0.00000001, lastCandle.close * (1 + deltaPercent));
      const newHigh = Math.max(lastCandle.high, newClose);
      const newLow = Math.min(lastCandle.low, newClose);

      lastCandle.close = newClose;
      lastCandle.high = newHigh;
      lastCandle.low = newLow;

      if (this.currentMode === 'candles' && this.candleSeries) {
        this.candleSeries.update(lastCandle);
      } else if (this.currentMode === 'area' && this.areaSeries) {
        this.areaSeries.update({ time: lastCandle.time, value: newClose });
      }

      // Update volume
      const lastVol = data.volume[data.volume.length - 1];
      lastVol.value += Math.round(Math.random() * 800);
      lastVol.color = newClose >= lastCandle.open ? 'rgba(16, 185, 129, 0.5)' : 'rgba(239, 68, 68, 0.5)';
      this.volumeSeries.update(lastVol);
    }, 2800);
  }

  private getOrGenerateData(tf: Timeframe) {
    if (this.cache.has(tf)) {
      return this.cache.get(tf)!;
    }

    let barCount = 96;
    let stepSeconds = 15 * 60; // 15 min default
    if (tf === '1h') {
      barCount = 72;
      stepSeconds = 60 * 60;
    } else if (tf === '4h') {
      barCount = 60;
      stepSeconds = 4 * 60 * 60;
    } else if (tf === '1D') {
      barCount = 45;
      stepSeconds = 24 * 60 * 60;
    }

    const now = Math.floor(Date.now() / 1000);
    // Align now to step
    const alignedNow = now - (now % stepSeconds);

    const candles: CandlestickData<Time>[] = [];
    const volumes: HistogramData<Time>[] = [];

    // Net drift calculation so the path ends exactly at currentPrice
    const overallReturn = this.change24h / 100;
    const startPrice = this.currentPrice / (1 + overallReturn);

    let price = startPrice > 0 ? startPrice : this.currentPrice * 0.85;
    const avgVolPerBar = this.volume24h / (24 / (stepSeconds / 3600));

    for (let i = 0; i < barCount; i++) {
      const time = (alignedNow - (barCount - 1 - i) * stepSeconds) as Time;
      // Progress fraction from 0 to 1
      const progress = i / (barCount - 1);
      // Target price curve with random walk
      const target = startPrice + (this.currentPrice - startPrice) * progress;
      const noise = (Math.random() - 0.495) * (price * 0.035);
      const open = price;
      let close = i === barCount - 1 ? this.currentPrice : target + noise;
      if (close <= 0) close = 0.0000001;

      const wickMax = Math.max(open, close);
      const wickMin = Math.min(open, close);
      const high = wickMax + Math.random() * (wickMax * 0.015);
      const low = Math.max(0.00000001, wickMin - Math.random() * (wickMin * 0.015));

      candles.push({
        time,
        open,
        high,
        low,
        close,
      });

      const isUp = close >= open;
      const vol = Math.max(1000, avgVolPerBar * (0.4 + Math.random() * 1.4));
      volumes.push({
        time,
        value: vol,
        color: isUp ? 'rgba(16, 185, 129, 0.45)' : 'rgba(239, 68, 68, 0.45)',
      });

      price = close;
    }

    const res = { candles, volume: volumes };
    this.cache.set(tf, res);
    return res;
  }

  public resize(width: number, height: number) {
    this.chart.applyOptions({ width, height });
  }

  public destroy() {
    if (this.liveTickInterval) {
      clearInterval(this.liveTickInterval);
      this.liveTickInterval = null;
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.chart.remove();
  }
}
